using UnityEngine;

/// <summary>
/// Comprehensive guide for Unity Editor timing issues and solutions.
/// 
/// COMMON TIMING ISSUES IN UNITY EDITOR:
/// 
/// 1. TIME SCALE SENSITIVITY
///    - WaitForSeconds() respects Time.timeScale
///    - In Editor, Time.timeScale might be modified by other systems
///    - SOLUTION: Use WaitForSecondsRealtime() instead
/// 
/// 2. EDITOR SIMULATION DIFFERENCES
///    - Editor might pause/resume execution unpredictably
///    - Background processing can affect timing
///    - SOLUTION: Use Time.realtimeSinceStartup for measurements
/// 
/// 3. FRAME RATE VARIATIONS
///    - Editor frame rate can be inconsistent
///    - Build frame rate is usually more stable
///    - SOLUTION: Combine frame-based and time-based approaches
/// 
/// 4. COROUTINE EXECUTION ORDER
///    - Editor might execute coroutines differently
///    - Especially when Editor loses/gains focus
///    - SOLUTION: Use multiple yield strategies
/// 
/// 5. INVOKE METHODS
///    - Invoke() might not work reliably in Editor play mode
///    - Works fine in builds
///    - SOLUTION: Use coroutines instead of Invoke()
/// 
/// RECOMMENDED PATTERNS FOR AR VOICE RECOGNITION:
/// </summary>
public class UnityEditorTimingGuide : MonoBehaviour
{
    [Header("Timing Issue Diagnostics")]
    [Tooltip("Check this to see if your timing issues are Editor-specific")]
    public bool isRunningInEditor;
    
    [Tooltip("Current time scale - should be 1.0 for normal timing")]
    public float currentTimeScale;
    
    [Tooltip("Difference between scaled and unscaled time")]
    public float timeDifference;
    
    void Start()
    {
        isRunningInEditor = Application.isEditor;
        
        Debug.Log("🔍 TIMING DIAGNOSTICS:");
        Debug.Log($"   Running in Editor: {isRunningInEditor}");
        Debug.Log($"   Platform: {Application.platform}");
        Debug.Log($"   Time Scale: {Time.timeScale}");
        Debug.Log($"   Target Frame Rate: {Application.targetFrameRate}");
        Debug.Log($"   VSync Count: {QualitySettings.vSyncCount}");
    }
    
    void Update()
    {
        isRunningInEditor = Application.isEditor;
        currentTimeScale = Time.timeScale;
        timeDifference = Time.time - Time.unscaledTime;
        
        // Warn if time scale is not 1
        if (Mathf.Abs(Time.timeScale - 1f) > 0.01f)
        {
            Debug.LogWarning($"⚠️ Time.timeScale is {Time.timeScale:F2} - this will affect WaitForSeconds!");
        }
    }
    
    /// <summary>
    /// BEST PRACTICE 1: Robust Delay Function
    /// Use this instead of simple WaitForSeconds() for critical timing
    /// </summary>
    public static System.Collections.IEnumerator RobustDelay(float seconds)
    {
        // Use real time to avoid time scale issues
        float startTime = Time.realtimeSinceStartup;
        
        while ((Time.realtimeSinceStartup - startTime) < seconds)
        {
            // Multiple yield strategies for Editor compatibility
            yield return new WaitForSecondsRealtime(0.1f);
            yield return null; // Ensure at least one frame passes
        }
    }
    
    /// <summary>
    /// BEST PRACTICE 2: Condition Waiting with Timeout
    /// Perfect for waiting for WhisperManager to load
    /// </summary>
    public static System.Collections.IEnumerator WaitForConditionWithTimeout(
        System.Func<bool> condition, 
        float timeout,
        System.Action<float> onProgressUpdate = null)
    {
        float startTime = Time.realtimeSinceStartup;
        
        while (!condition() && (Time.realtimeSinceStartup - startTime) < timeout)
        {
            float elapsed = Time.realtimeSinceStartup - startTime;
            onProgressUpdate?.Invoke(elapsed);
            
            // Multiple yield strategies
            yield return new WaitForSecondsRealtime(0.1f);
            yield return null;
        }
    }
    
    /// <summary>
    /// BEST PRACTICE 3: Replace Invoke with Coroutines
    /// More reliable in Editor
    /// </summary>
    public void SafeDelayedCall(System.Action callback, float delay)
    {
        StartCoroutine(DelayedCallCoroutine(callback, delay));
    }
    
    private System.Collections.IEnumerator DelayedCallCoroutine(System.Action callback, float delay)
    {
        yield return RobustDelay(delay);
        callback?.Invoke();
    }
    
    /// <summary>
    /// DEBUGGING: Test various timing methods to see which work in your setup
    /// </summary>
    [ContextMenu("Test All Timing Methods")]
    public void TestAllTimingMethods()
    {
        StartCoroutine(RunTimingTests());
    }
    
    private System.Collections.IEnumerator RunTimingTests()
    {
        Debug.Log("🔍 Testing timing methods...");
        
        // Test 1: Basic WaitForSeconds
        float start = Time.realtimeSinceStartup;
        yield return new WaitForSeconds(1f);
        float elapsed1 = Time.realtimeSinceStartup - start;
        Debug.Log($"WaitForSeconds(1f): {elapsed1:F2}s (should be ~1.0)");
        
        // Test 2: WaitForSecondsRealtime
        start = Time.realtimeSinceStartup;
        yield return new WaitForSecondsRealtime(1f);
        float elapsed2 = Time.realtimeSinceStartup - start;
        Debug.Log($"WaitForSecondsRealtime(1f): {elapsed2:F2}s (should be ~1.0)");
        
        // Test 3: Custom frame-based timer
        start = Time.realtimeSinceStartup;
        yield return RobustDelay(1f);
        float elapsed3 = Time.realtimeSinceStartup - start;
        Debug.Log($"RobustDelay(1f): {elapsed3:F2}s (should be ~1.0)");
        
        // Test 4: Invoke (might not work in Editor)
        start = Time.realtimeSinceStartup;
        bool invokeCompleted = false;
        Invoke(nameof(TestInvokeCallback), 1f);
        
        // Wait for invoke to complete or timeout
        while (!invokeCompleted && (Time.realtimeSinceStartup - start) < 2f)
        {
            yield return null;
        }
        
        if (!invokeCompleted)
        {
            Debug.LogWarning("Invoke test timed out - this is common in Editor!");
        }
        
        Debug.Log("🔍 Timing tests completed!");
    }
    
    private void TestInvokeCallback()
    {
        float elapsed = Time.realtimeSinceStartup - Time.time;
        Debug.Log($"Invoke callback executed");
    }
}

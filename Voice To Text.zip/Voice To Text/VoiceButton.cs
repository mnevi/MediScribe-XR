using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using Whisper.Utils;

/// <summary>
/// Simple and robust voice recognition button for controlling ARVoiceRecognitionCore
/// </summary>
public class VoiceButton : MonoBehaviour
{
    [Header("Required Components")]
    [Tooltip("The UI Button component")]
    public Button recordButton;
    
    [Header("Text Component - Choose One")]
    [Tooltip("TextMeshPro text component")]
    public TextMeshProUGUI buttonTextTMP;
    
    [Tooltip("Legacy Unity Text component")]
    public Text buttonText;
    
    [Header("Button Configuration")]
    public string idleText = "Record";
    public string recordingText = "Stop";
    public string processingText = "Processing...";
    public string errorText = "Error";
    
    [Header("Button Colors")]
    public Color idleColor = new Color(0.2f, 0.7f, 0.3f, 1f);
    public Color recordingColor = new Color(0.8f, 0.2f, 0.2f, 1f);
    public Color processingColor = new Color(0.8f, 0.6f, 0.2f, 1f);
    public Color errorColor = new Color(0.5f, 0.5f, 0.5f, 1f);
    
    [Header("Settings")]
    [Tooltip("Enable debug logging")]
    public bool enableDebugLogging = true;
    
    [Tooltip("Minimum time between button clicks")]
    public float clickCooldown = 0.5f;
    
    [Tooltip("Time to wait before allowing clicks after error")]
    public float errorRecoveryTime = 2f;
    
    // Components
    private ARVoiceRecognitionCore voiceCore;
    private MicrophoneRecord microphoneRecord;
    
    // State tracking
    private bool isRecording = false;
    private bool isProcessing = false;
    private bool isInError = false;
    private bool isInitialized = false;
    
    // Timing
    private float lastClickTime = 0f;
    private float lastErrorTime = 0f;
    
    // Coroutines
    private Coroutine recoveryCoroutine;
    
    private enum ButtonState
    {
        Idle,
        Recording,
        Processing,
        Error
    }
    
    private void Start()
    {
        StartCoroutine(Initialize());
    }
    
    private IEnumerator Initialize()
    {
        yield return new WaitForEndOfFrame();
        
        if (!ValidateComponents())
        {
            Log("Initialization failed - missing components", true);
            SetButtonState(ButtonState.Error);
            yield break;
        }
        
        SetupButton();
        ConnectVoiceEvents();
        SetButtonState(ButtonState.Idle);
        
        isInitialized = true;
        Log("Voice button initialized successfully");
    }
    
    private bool ValidateComponents()
    {
        bool isValid = true;
        
        // Validate button
        if (recordButton == null)
        {
            Log("Record button is not assigned", true);
            isValid = false;
        }
        
        // Validate text component
        if (buttonTextTMP == null && buttonText == null)
        {
            Log("No text component assigned", true);
            isValid = false;
        }
        
        // Find voice core
        voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
        if (voiceCore == null)
        {
            Log("ARVoiceRecognitionCore not found in scene", true);
            isValid = false;
        }
        
        // Find microphone record
        microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
        if (microphoneRecord == null && voiceCore != null)
        {
            microphoneRecord = voiceCore.microphoneRecord;
        }
        
        if (microphoneRecord == null)
        {
            Log("MicrophoneRecord component not found", true);
            isValid = false;
        }
        
        return isValid;
    }
    
    private void SetupButton()
    {
        if (recordButton == null) return;
        
        recordButton.onClick.RemoveAllListeners();
        recordButton.onClick.AddListener(OnButtonClick);
        Log("Button setup complete");
    }
    
    private void ConnectVoiceEvents()
    {
        if (voiceCore == null) return;
        
        if (voiceCore.OnRecordingStateChanged != null)
            voiceCore.OnRecordingStateChanged.AddListener(OnRecordingStateChanged);
        
        if (voiceCore.OnStatusChanged != null)
            voiceCore.OnStatusChanged.AddListener(OnStatusChanged);
        
        if (voiceCore.OnErrorOccurred != null)
            voiceCore.OnErrorOccurred.AddListener(OnVoiceError);
        
        Log("Voice events connected");
    }
    
    private void OnButtonClick()
    {
        if (!CanProcessClick()) return;
        
        lastClickTime = Time.time;
        Log($"Button clicked - Current state: Recording={isRecording}, Processing={isProcessing}");
        
        if (isProcessing)
        {
            Log("Already processing, ignoring click");
            return;
        }
        
        StartCoroutine(HandleVoiceToggle());
    }
    
    private bool CanProcessClick()
    {
        // Check initialization
        if (!isInitialized)
        {
            Log("Button not initialized", true);
            return false;
        }
        
        // Check error cooldown
        if (isInError && Time.time - lastErrorTime < errorRecoveryTime)
        {
            Log("Still in error recovery period");
            return false;
        }
        
        // Check click cooldown
        if (Time.time - lastClickTime < clickCooldown)
        {
            Log("Click too soon, ignoring");
            return false;
        }
        
        // Check component validity
        if (voiceCore == null || !voiceCore.enabled || !voiceCore.gameObject.activeInHierarchy)
        {
            Log("Voice core is not available", true);
            HandleError("Voice core unavailable");
            return false;
        }
        
        return true;
    }
    
    private IEnumerator HandleVoiceToggle()
    {
        isProcessing = true;
        SetButtonState(ButtonState.Processing);
        
        bool success = false;
        
        try
        {
            Log($"Toggling voice recognition (currently recording: {isRecording})");
            voiceCore.ToggleVoiceRecognition();
            success = true;
        }
        catch (System.Exception ex)
        {
            Log($"Voice toggle failed: {ex.Message}", true);
            HandleError("Voice toggle failed");
        }
        
        if (success)
        {
            // Wait briefly for state to update
            yield return new WaitForSeconds(0.2f);
            
            // Update our state to match the voice core
            isRecording = voiceCore.IsRecording;
            isInError = false;
            
            SetButtonState(isRecording ? ButtonState.Recording : ButtonState.Idle);
            Log($"Voice toggle complete - Now recording: {isRecording}");
        }
        
        isProcessing = false;
    }
    
    private void HandleError(string message)
    {
        isInError = true;
        lastErrorTime = Time.time;
        SetButtonState(ButtonState.Error);
        
        Log($"Error: {message}", true);
        
        // Start recovery after delay
        if (recoveryCoroutine != null)
            StopCoroutine(recoveryCoroutine);
        
        recoveryCoroutine = StartCoroutine(RecoverFromError());
    }
    
    private IEnumerator RecoverFromError()
    {
        yield return new WaitForSeconds(errorRecoveryTime);
        
        Log("Attempting error recovery");
        
        if (ValidateComponents())
        {
            isInError = false;
            SetButtonState(ButtonState.Idle);
            Log("Error recovery successful");
        }
        else
        {
            Log("Error recovery failed - will retry", true);
            yield return new WaitForSeconds(2f);
            StartCoroutine(RecoverFromError());
        }
    }
    
    private void SetButtonState(ButtonState state)
    {
        if (recordButton == null) return;
        
        string text;
        Color color;
        bool interactable = true;
        
        switch (state)
        {
            case ButtonState.Recording:
                text = recordingText;
                color = recordingColor;
                break;
            case ButtonState.Processing:
                text = processingText;
                color = processingColor;
                interactable = false;
                break;
            case ButtonState.Error:
                text = errorText;
                color = errorColor;
                interactable = false;
                break;
            default: // Idle
                text = idleText;
                color = idleColor;
                break;
        }
        
        UpdateButtonText(text);
        UpdateButtonColor(color);
        recordButton.interactable = interactable;
        
        Log($"Button state: {state}");
    }
    
    private void UpdateButtonText(string text)
    {
        if (buttonTextTMP != null)
            buttonTextTMP.text = text;
        else if (buttonText != null)
            buttonText.text = text;
    }
    
    private void UpdateButtonColor(Color color)
    {
        if (recordButton == null) return;
        
        var colors = recordButton.colors;
        colors.normalColor = color;
        colors.highlightedColor = Color.Lerp(color, Color.white, 0.2f);
        colors.pressedColor = Color.Lerp(color, Color.black, 0.2f);
        colors.disabledColor = Color.Lerp(color, Color.gray, 0.5f);
        recordButton.colors = colors;
    }
    
    // Event handlers
    private void OnRecordingStateChanged(bool recording)
    {
        if (!isInitialized || isProcessing) return;
        
        isRecording = recording;
        SetButtonState(recording ? ButtonState.Recording : ButtonState.Idle);
        Log($"Recording state changed: {recording}");
    }
    
    private void OnStatusChanged(string status)
    {
        if (!isInitialized) return;
        
        bool wasProcessing = isProcessing;
        isProcessing = status.Contains("Processing") || status.Contains("Loading");
        
        if (wasProcessing != isProcessing && !isRecording)
        {
            SetButtonState(isProcessing ? ButtonState.Processing : ButtonState.Idle);
        }
        
        Log($"Status changed: {status}");
    }
    
    private void OnVoiceError(string error)
    {
        Log($"Voice core error: {error}", true);
        HandleError($"Voice error: {error}");
    }
    
    private void Log(string message, bool isError = false)
    {
        if (!enableDebugLogging) return;
        
        string prefix = "[VoiceButton]";
        if (isError)
            Debug.LogError($"{prefix} {message}");
        else
            Debug.Log($"{prefix} {message}");
    }
    
    // Public interface for external control
    public void ForceReset()
    {
        Log("Force reset requested");
        isInError = false;
        isProcessing = false;
        
        if (recoveryCoroutine != null)
        {
            StopCoroutine(recoveryCoroutine);
            recoveryCoroutine = null;
        }
        
        StartCoroutine(Initialize());
    }
    
    // Properties for external monitoring
    public bool IsRecording => isRecording;
    public bool IsProcessing => isProcessing;
    public bool IsInError => isInError;
    public bool IsInitialized => isInitialized;
    
    private void OnDestroy()
    {
        if (recoveryCoroutine != null)
            StopCoroutine(recoveryCoroutine);
    }
}

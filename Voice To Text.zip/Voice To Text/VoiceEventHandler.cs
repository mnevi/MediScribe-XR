using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// Simple event handler for ARVoiceRecognitionCore events
/// Attach this to a GameObject and connect it to the events in Inspector
/// </summary>
public class VoiceEventHandler : MonoBehaviour
{
    [Header("UI Components to Update")]
    public Text transcriptionDisplay;
    public Text statusDisplay;
    public Image recordingIndicator;
    public Button recordButton;

    [Header("Debounce Settings")]
    [Tooltip("Minimum time between record button clicks (in seconds)")]
    public float debounceDuration = 1.0f;
    private bool isDebounced = false;
    
    [Header("Voice Recognition Connection")]
    [Tooltip("The ARVoiceRecognitionCore to control")]
    public ARVoiceRecognitionCore voiceCore;
    
    [Header("Visual Settings")]
    public Color recordingColor = Color.red;
    public Color idleColor = Color.gray;
    
    [Header("Medical AR Settings")]
    [Tooltip("Limit transcription display length for AR readability")]
    public int maxDisplayLength = 50;
    
    [Tooltip("Auto-clear transcription after this many seconds (0 = disabled)")]
    public float autoClearDelay = 10f;
    
    private Coroutine autoClearCoroutine;
    
    private void Start()
    {
        // Setup button click handler
        bool debounce = false;

        if (recordButton != null && voiceCore != null)
        {
            if (debounce == false)
            {
                recordButton.onClick.AddListener(OnRecordButtonClicked); 
                
            }
        }
        else
        {
            if (recordButton == null)
                Debug.LogWarning("VoiceEventHandler: Record button not assigned!");
            if (voiceCore == null)
                Debug.LogWarning("VoiceEventHandler: Voice core not assigned!");
        }
    }
    
    private void OnRecordButtonClicked()
    {
        if (isDebounced)
        {
            Debug.Log("🛑 Debounced: Click ignored.");
            return;
        }

        if (voiceCore != null)
        {
            voiceCore.ToggleVoiceRecognition();
            StartCoroutine(DebounceButton()); // <== Now we're calling the coroutine here
        }
    }
    
    private IEnumerator DebounceButton()
    {
        isDebounced = true;
        yield return new WaitForSeconds(debounceDuration);
        isDebounced = false;
    }


    
    // Event handler methods (these will appear in the Inspector dropdown)
    public void OnTranscriptionReceived(string transcription)
    {
        if (transcriptionDisplay != null)
        {
            string displayText = transcription;

            // Handle both partial and final results
            if (transcription.StartsWith("[Partial]"))
            {
                displayText = "🎤 " + transcription.Substring(10);
                transcriptionDisplay.color = Color.yellow; // Partial result color
            }
            else if (transcription.StartsWith("[Final]"))
            {
                displayText = "✅ " + transcription.Substring(8);
                transcriptionDisplay.color = Color.white; // Final result color

                // Start auto-clear timer for final results
                if (autoClearDelay > 0)
                {
                    if (autoClearCoroutine != null)
                        StopCoroutine(autoClearCoroutine);
                    autoClearCoroutine = StartCoroutine(AutoClearAfterDelay());
                }
            }
            else
            {
                transcriptionDisplay.color = Color.white;
            }

            // Limit display length for AR readability
            if (displayText.Length > maxDisplayLength)
            {
                displayText = displayText.Substring(0, maxDisplayLength) + "...";
            }

            transcriptionDisplay.text = displayText;
        }

        Debug.Log($"Transcription Event: {transcription}");
    }
    
    private System.Collections.IEnumerator AutoClearAfterDelay()
    {
        Debug.Log($"🔍 [TIMER DEBUG] Auto-clear started. Delay: {autoClearDelay}s");
        
        // Use a more reliable timer approach
        float startTime = Time.realtimeSinceStartup;
        
        while ((Time.realtimeSinceStartup - startTime) < autoClearDelay)
        {
            yield return new WaitForSecondsRealtime(0.1f);
            yield return null; // Wait one frame for Editor compatibility
            
            float elapsed = Time.realtimeSinceStartup - startTime;
            
            // Debug every second
            if (elapsed % 1f < 0.1f)
            {
                Debug.Log($"🔍 [TIMER DEBUG] Auto-clear timer: {elapsed:F1}s / {autoClearDelay}s");
            }
        }
        
        float finalElapsed = Time.realtimeSinceStartup - startTime;
        Debug.Log($"🔍 [TIMER DEBUG] Auto-clear timer completed in {finalElapsed:F1}s. Clearing transcription...");
        ClearTranscription();
    }
    
    public void OnStatusChanged(string status)
    {
        if (statusDisplay != null)
        {
            statusDisplay.text = $"Status: {status}";
            
            // Change color based on status
            if (status.Contains("Error"))
                statusDisplay.color = Color.red;
            else if (status.Contains("Ready"))
                statusDisplay.color = Color.green;
            else if (status.Contains("Listening"))
                statusDisplay.color = Color.cyan;
            else
                statusDisplay.color = Color.white;
        }
        
        Debug.Log($"Status Event: {status}");
    }
    
    public void OnRecordingStateChanged(bool isRecording)
    {
        // Update recording indicator
        if (recordingIndicator != null)
        {
            recordingIndicator.enabled = isRecording;
            recordingIndicator.color = isRecording ? recordingColor : idleColor;
        }
        
        // Update button text
        if (recordButton != null)
        {
            // Try TextMeshPro first, then regular Text component
            TextMeshProUGUI buttonTextTMP = recordButton.GetComponentInChildren<TextMeshProUGUI>();
            Text buttonTextRegular = recordButton.GetComponentInChildren<Text>();
            
            if (buttonTextTMP != null)
            {
                buttonTextTMP.text = isRecording ? "🛑 Stop" : "🎤 Record";
            }
            else if (buttonTextRegular != null)
            {
                buttonTextRegular.text = isRecording ? "🛑 Stop" : "🎤 Record";
            }
            else
            {
                Debug.LogWarning("Record button doesn't have a Text or TextMeshPro component in its children");
            }
        }
        
        Debug.Log($"Recording State Event: {isRecording}");
    }
    
    public void OnErrorOccurred(string error)
    {
        Debug.LogError($"Voice Recognition Error: {error}");
        
        // Show error in status if available
        if (statusDisplay != null)
        {
            statusDisplay.text = $"Error: {error}";
            statusDisplay.color = Color.red;
        }
        
        // You could also show a popup or notification here
    }
    
    // Additional helper methods for Inspector use
    public void ClearTranscription()
    {
        if (transcriptionDisplay != null)
            transcriptionDisplay.text = "";
    }
    
    public void ResetStatus()
    {
        if (statusDisplay != null)
        {
            statusDisplay.text = "Ready";
            statusDisplay.color = Color.green;
        }
    }
    
    private void OnDestroy()
    {
        // Clean up button listener
        if (recordButton != null)
        {
            recordButton.onClick.RemoveListener(OnRecordButtonClicked);
        }
    }
}

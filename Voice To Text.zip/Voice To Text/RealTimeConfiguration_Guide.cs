// Real-time Transcription Configuration Guide for Medical AR
// Place this in your medical documentation for reference

/*
WHISPER MANAGER SETTINGS FOR REAL-TIME:
========================================

Basic Settings:
- Print Realtime: TRUE ✓
- Print Progress: TRUE ✓
- Language: "en"
- Temperature: 0.0 (medical accuracy)

Performance Settings:
- Model: ggml-tiny.bin (fastest) or ggml-base.bin (more accurate)
- GPU: TRUE (if available on AR device)
- Max Length: 0 (unlimited)
- Suppress Blank: TRUE ✓
- Suppress Non Speech Tokens: TRUE ✓

MICROPHONE RECORD SETTINGS:
===========================

Audio Quality:
- Frequency: 16000 Hz
- Chunks Length Sec: 0.5 (faster real-time updates)
- Max Length Sec: 30

Voice Activity Detection:
- Use Vad: TRUE ✓
- Vad Update Rate Sec: 0.1 (very responsive)
- Vad Threshold: 0.4 (adjust based on environment)

AR VOICE RECOGNITION CORE SETTINGS:
===================================

Real-time Display:
- Enable Real Time Display: TRUE ✓
- Confidence Threshold: 0.3 (lower = more partial results)
- Update Frequency: 0.5 seconds (balance responsiveness/performance)

Medical Workflow:
- Auto Hide: TRUE (clean AR interface)
- Status Text: Assign for quick testing, leave empty for custom UI

MEDICAL AR OPTIMIZATION:
========================

For Operating Room:
- Confidence Threshold: 0.4 (reduce false positives)
- Update Frequency: 0.3 (more responsive)
- Vad Threshold: 0.5 (filter background noise)

For Patient Consultation:
- Confidence Threshold: 0.2 (capture more speech)
- Update Frequency: 0.5 (balanced)
- Vad Threshold: 0.3 (sensitive to quiet speech)

For Emergency Settings:
- Enable Real Time Display: TRUE
- Update Frequency: 0.2 (maximum responsiveness)
- Auto Hide: FALSE (keep transcription visible)

TROUBLESHOOTING REAL-TIME ISSUES:
=================================

If transcription is too slow:
- Reduce Chunks Length Sec to 0.3
- Use ggml-tiny.bin model
- Enable GPU acceleration
- Reduce Update Frequency to 0.3

If too many partial results:
- Increase Confidence Threshold to 0.5
- Increase Update Frequency to 1.0
- Enable Suppress Blank and Suppress Non Speech Tokens

If missing speech:
- Decrease Vad Threshold to 0.2
- Decrease Confidence Threshold to 0.1
- Increase Vad Update Rate Sec to 0.05

EXAMPLE CODE USAGE:
==================

// Enable real-time for surgery
voiceCore.SetRealTimeSettings(true, 0.4f, 0.3f);

// Disable real-time for final documentation
voiceCore.EnableRealTimeDisplay(false);

// Listen to real-time events
voiceCore.OnTranscriptionReceived.AddListener((text) => {
    if (text.StartsWith("[Partial]")) {
        // Handle real-time partial results
        UpdatePartialDisplay(text.Substring(10));
    } else if (text.StartsWith("[Final]")) {
        // Handle final transcription
        SaveToMedicalRecord(text.Substring(8));
    }
});
*/

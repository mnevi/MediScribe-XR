# Button onClick Setup Guide for AR Voice Recognition

## 🆕 **NEW: Visual Button Changes (Recommended)**

### **Automatic Text & Color Changes**
For buttons that automatically change appearance when recording:

```
1. Select your button GameObject  
2. Add Component → VoiceRecognitionButtonPro
3. Auto-configures with ARVoiceRecognitionCore
4. Button automatically changes:
   - 🎤 Idle: Green "Record" 
   - 🛑 Recording: Red "Stop"
   - ⏳ Processing: Orange "Processing..." (disabled)
```

**Benefits**: Professional UI, clear visual feedback, prevents user errors
**Setup Guide**: See `ButtonVisualChanges_Setup_Guide.md`

---

## 📋 **Manual onClick Setup (Alternative)**

If you prefer manual button control or custom behavior:

## Quick Reference - What to Add to Button OnClick Events

### Main Record/Stop Button
**For the primary voice recognition toggle button:**

#### Method 1: Direct Toggle (Simplest)
```
Button OnClick() → Add Event
Object: [Drag your GameObject with ARVoiceRecognitionCore]
Function: ARVoiceRecognitionCore → ToggleVoiceRecognition()
```

#### Method 2: Separate Start/Stop Buttons
**Start Recording Button:**
```
Button OnClick() → Add Event
Object: [Drag your GameObject with ARVoiceRecognitionCore]
Function: ARVoiceRecognitionCore → StartRecording()
```

**Stop Recording Button:**
```
Button OnClick() → Add Event  
Object: [Drag your GameObject with ARVoiceRecognitionCore]
Function: ARVoiceRecognitionCore → StopRecording()
```

### UI Management Buttons

#### Clear Transcription Button
```
Button OnClick() → Add Event
Object: [Drag your GameObject with VoiceEventHandler]
Function: VoiceEventHandler → ClearTranscription()
```

#### Reset Status Button
```
Button OnClick() → Add Event
Object: [Drag your GameObject with VoiceEventHandler] 
Function: VoiceEventHandler → ResetStatus()
```

### Diagnostic and Setup Buttons

#### Test Scene Setup Button
```
Button OnClick() → Add Event
Object: [Drag your GameObject with SceneSetupChecker]
Function: SceneSetupChecker → CheckSceneSetup()
```

#### Auto-Fix Issues Button
```
Button OnClick() → Add Event
Object: [Drag your GameObject with SceneSetupChecker]
Function: SceneSetupChecker → FixCommonIssues()
```

#### Download Models Button
```
Button OnClick() → Add Event
Object: [Drag your GameObject with WhisperModelDownloader]
Function: WhisperModelDownloader → DownloadBaseModel()
```

## Step-by-Step Button Setup

### 1. Main Voice Recognition Button (Recommended)

1. **Create Button:**
   ```
   Right-click in Hierarchy → UI → Button - TextMeshPro
   Name it: "RecordButton"
   ```

2. **Set Button Text:**
   ```
   Select RecordButton → Child "Text (TMP)"
   Text: "🎤 Start Recording"
   ```

3. **Configure OnClick Event:**
   ```
   Select RecordButton
   In Inspector → Button component
   OnClick() → Click "+"
   Drag your VoiceRecognitionManager GameObject to Object field
   Function dropdown → ARVoiceRecognitionCore → ToggleVoiceRecognition()
   ```

### 2. Automatic Button Text Updates

For buttons that change text based on recording state, use VoiceEventHandler:

1. **Setup VoiceEventHandler:**
   ```
   Add VoiceEventHandler component to UI GameObject
   Assign:
   - Voice Core: [Your ARVoiceRecognitionCore GameObject]
   - Record Button: [Your button]
   ```

2. **Connect Events in ARVoiceRecognitionCore:**
   ```
   Select VoiceRecognitionManager
   In ARVoiceRecognitionCore → Events:
   
   OnRecordingStateChanged():
   - Click "+"
   - Object: [VoiceEventHandler GameObject]
   - Function: VoiceEventHandler → OnRecordingStateChanged(bool)
   ```

### 3. Multiple Button Setup Example

#### HTML-Style Layout:
```
Canvas
├── MainPanel
│   ├── RecordButton (Toggle Recording)
│   ├── ClearButton (Clear Text)
│   └── StatusButton (Reset Status)
├── DiagnosticPanel
│   ├── CheckSetupButton
│   ├── FixIssuesButton
│   └── DownloadModelsButton
└── DisplayPanel
    ├── TranscriptionText
    └── StatusText
```

#### Button OnClick Assignments:
```
RecordButton → ARVoiceRecognitionCore.ToggleVoiceRecognition()
ClearButton → VoiceEventHandler.ClearTranscription()
StatusButton → VoiceEventHandler.ResetStatus()
CheckSetupButton → SceneSetupChecker.CheckSceneSetup()
FixIssuesButton → SceneSetupChecker.FixCommonIssues()
DownloadModelsButton → WhisperModelDownloader.DownloadBaseModel()
```

## Advanced Button Configurations

### 1. Medical AR Specific Buttons

#### Save Transcription Button
```csharp
// Create custom script for medical features
public class MedicalARButtons : MonoBehaviour
{
    public ARVoiceRecognitionCore voiceCore;
    
    public void SaveTranscription()
    {
        string transcription = voiceCore.LastTranscription;
        // Save to file or medical system
        Debug.Log($"Saving: {transcription}");
    }
    
    public void StartPatientNote()
    {
        voiceCore.StartRecording();
        // Additional medical context setup
    }
}

// Button OnClick: MedicalARButtons.SaveTranscription()
```

#### Quick Medical Commands
```csharp
public void InsertMedicalTemplate(string template)
{
    // Insert pre-defined medical text
    switch(template)
    {
        case "examination":
            // Insert examination template
            break;
        case "diagnosis":  
            // Insert diagnosis template
            break;
    }
}

// Button OnClick: MedicalARButtons.InsertMedicalTemplate("examination")
```

### 2. Real-time Settings Buttons

#### Enable/Disable Real-time Display
```
Button OnClick() → Add Event
Object: [ARVoiceRecognitionCore GameObject]
Function: ARVoiceRecognitionCore → EnableRealTimeDisplay(bool)
Parameter: ✓ (for enable) or ✗ (for disable)
```

#### Adjust Confidence Threshold
```csharp
// Custom script for settings
public class VoiceSettings : MonoBehaviour
{
    public ARVoiceRecognitionCore voiceCore;
    
    public void SetHighAccuracy() 
    { 
        voiceCore.SetRealTimeSettings(true, 0.7f, 0.3f); 
    }
    
    public void SetFastResponse() 
    { 
        voiceCore.SetRealTimeSettings(true, 0.2f, 0.1f); 
    }
}
```

### 3. Debug and Testing Buttons

#### Reinitialize System
```
Button OnClick() → ARVoiceRecognitionCore → ReinitializeVoiceRecognition()
```

#### Test Diagnostics
```
Button OnClick() → ARVoiceRecognitionDiagnostic → RunDiagnostics()
```

#### Check Models
```
Button OnClick() → WhisperModelDownloader → CheckAvailableModels()
```

## Common Button Event Patterns

### Pattern 1: Simple Toggle
```
Single button that changes between "Start" and "Stop"
OnClick: ARVoiceRecognitionCore.ToggleVoiceRecognition()
Text updates automatically via VoiceEventHandler
```

### Pattern 2: Separate Start/Stop
```
Two buttons: "Start Recording" and "Stop Recording"
Start OnClick: ARVoiceRecognitionCore.StartRecording()
Stop OnClick: ARVoiceRecognitionCore.StopRecording()
```

### Pattern 3: Medical Workflow
```
"Start Patient Note" → StartRecording() + medical context
"Complete Note" → StopRecording() + save to medical system
"Quick Save" → Save current transcription
"Templates" → Insert medical templates
```

## UI Event Wiring Checklist

✅ **Record Button** → `ARVoiceRecognitionCore.ToggleVoiceRecognition()`
✅ **Clear Button** → `VoiceEventHandler.ClearTranscription()`
✅ **Status Reset** → `VoiceEventHandler.ResetStatus()`
✅ **Setup Check** → `SceneSetupChecker.CheckSceneSetup()`
✅ **Auto-Fix** → `SceneSetupChecker.FixCommonIssues()`
✅ **Download Models** → `WhisperModelDownloader.DownloadBaseModel()`

## Testing Your Button Setup

1. **Enter Play Mode**
2. **Click Record Button** → Should see "Listening..." status
3. **Speak into microphone** → Should see transcription appear
4. **Click Stop/Record again** → Should stop recording
5. **Click Clear** → Should clear transcription text
6. **Check Console** → Should see debug messages for each action

The most important button is the main record toggle - start with that one!

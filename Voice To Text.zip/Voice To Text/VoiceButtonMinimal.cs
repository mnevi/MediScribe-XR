using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Minimal crash-proof voice recognition button
/// This version has ZERO external dependencies and cannot crash Unity
/// </summary>
public class VoiceButtonMinimal : MonoBehaviour
{
    [Header("Required Components")]
    public Button button;
    public TextMeshProUGUI buttonText;
    
    [Header("Button States")]
    public string idleText = "Record";
    public string recordingText = "Stop";
    public Color idleColor = Color.green;
    public Color recordingColor = Color.red;
    
    [Header("Debug Options")]
    [Tooltip("Enable detailed logging for button state changes")]
    public bool enableDebugLogging = true;
    
    [Tooltip("Force button to always stay interactable")]
    public bool forceInteractable = true;
    
    // Simple state tracking
    private bool isRecording = false;
    
    void Start()
    {
        // Absolutely minimal setup with maximum safety
        try
        {
            InitializeButton();
        }
        catch (System.Exception e)
        {
            Debug.LogError($"VoiceButtonMinimal initialization error (non-critical): {e.Message}");
        }
    }
    
    void InitializeButton()
    {
        // Auto-find button if not assigned
        if (button == null)
        {
            button = GetComponent<Button>();
        }
        
        // Auto-find text if not assigned
        if (buttonText == null)
        {
            buttonText = GetComponentInChildren<TextMeshProUGUI>();
        }
        
        // Only setup if we have a button
        if (button != null)
        {
            // Remove any existing listeners (safety)
            button.onClick.RemoveAllListeners();
            
            // Add our simple click handler
            button.onClick.AddListener(OnButtonClick);
            
            // Set initial state
            UpdateButtonVisuals();
            
            // Start monitoring button state if debugging enabled
            if (enableDebugLogging)
            {
                StartCoroutine(MonitorButtonState());
            }
            
            Debug.Log("✅ VoiceButtonMinimal: Initialized successfully");
        }
        else
        {
            Debug.LogError("❌ VoiceButtonMinimal: No Button component found");
        }
    }
    
    void OnButtonClick()
    {
        // ABSOLUTE MINIMUM CRASH PROTECTION
        try
        {
            // Safety check - absolutely required
            if (this == null || button == null) return;
            
            // Toggle state
            isRecording = !isRecording;
            
            // Update visuals
            UpdateButtonVisuals();
            
            // Log what happened
            Debug.Log($"🎤 Button clicked - Recording: {isRecording}");
            
            // Try to find and call voice recognition (safely)
            TryCallVoiceRecognition();
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Button click error (handled safely): {e.Message}");
            
            // Reset to safe state
            isRecording = false;
            UpdateButtonVisuals();
        }
    }
    
    void UpdateButtonVisuals()
    {
        // Update text (if available)
        if (buttonText != null)
        {
            try
            {
                buttonText.text = isRecording ? recordingText : idleText;
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Text update error (non-critical): {e.Message}");
            }
        }
        
        // Update color (if button available)
        if (button != null)
        {
            try
            {
                // Ensure button stays interactable if forced
                if (forceInteractable)
                {
                    button.interactable = true;
                }
                
                ColorBlock colors = button.colors;
                colors.normalColor = isRecording ? recordingColor : idleColor;
                colors.highlightedColor = Color.Lerp(colors.normalColor, Color.white, 0.2f);
                colors.pressedColor = Color.Lerp(colors.normalColor, Color.black, 0.2f);
                colors.selectedColor = colors.normalColor;
                colors.disabledColor = Color.gray; // This won't be used since we keep interactable = true
                
                button.colors = colors;
                
                // Debug log to track color changes
                if (enableDebugLogging)
                {
                    Debug.Log($"🎨 Button color updated - Recording: {isRecording}, Color: {colors.normalColor}, Interactable: {button.interactable}");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Color update error (non-critical): {e.Message}");
            }
        }
    }
    
    System.Collections.IEnumerator MonitorButtonState()
    {
        while (this != null && button != null)
        {
            // Check if button became disabled unexpectedly
            if (!button.interactable && forceInteractable)
            {
                try
                {
                    Debug.LogWarning("⚠️ Button became non-interactable! Re-enabling...");
                    button.interactable = true;
                }
                catch (System.Exception e)
                {
                    Debug.LogWarning($"Error re-enabling button: {e.Message}");
                }
            }
            
            // Check if button color became gray unexpectedly
            try
            {
                ColorBlock colors = button.colors;
                if (colors.normalColor == Color.gray && (!isRecording ? idleColor : recordingColor) != Color.gray)
                {
                    Debug.LogWarning("⚠️ Button color became gray unexpectedly! Fixing...");
                    UpdateButtonVisuals();
                }
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Error checking button color: {e.Message}");
            }
            
            yield return new WaitForSeconds(0.5f); // Check every half second
        }
    }
    
    void TryCallVoiceRecognition()
    {
        // TEMPORARILY DISABLED - Testing crash isolation
        // The crash is happening in voice recognition, so we'll isolate it completely
        
        Debug.Log("🔍 CRASH INVESTIGATION: Voice recognition call disabled for testing");
        Debug.Log("🔍 Button will only change visuals until crash source is identified");
        
        // TODO: Re-enable once crash source is found and fixed
        /*
        try
        {
            // Try to find ARVoiceRecognitionCore safely
            ARVoiceRecognitionCore voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
            
            if (voiceCore != null)
            {
                // Call voice recognition in protected way
                voiceCore.ToggleVoiceRecognition();
                Debug.Log("✅ Voice recognition toggled successfully");
            }
            else
            {
                Debug.LogWarning("⚠️ No ARVoiceRecognitionCore found - button will only change visuals");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Voice recognition error (handled safely): {e.Message}");
            Debug.LogError($"❌ Stack trace: {e.StackTrace}");
            
            // Even if voice recognition fails, keep button working
            Debug.Log("🔄 Button continues to work despite voice recognition error");
        }
        */
    }
    
    // Public methods for manual control
    public void SetRecording(bool recording)
    {
        try
        {
            isRecording = recording;
            UpdateButtonVisuals();
        }
        catch (System.Exception e)
        {
            Debug.LogError($"SetRecording error (handled): {e.Message}");
        }
    }
    
    public void ForceReset()
    {
        try
        {
            isRecording = false;
            UpdateButtonVisuals();
            Debug.Log("🔄 Button reset to idle state");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"ForceReset error (handled): {e.Message}");
        }
    }
    
    // Property to check state
    public bool IsRecording => isRecording;
    
    void OnDestroy()
    {
        try
        {
            // Clean up safely
            if (button != null)
            {
                button.onClick.RemoveAllListeners();
            }
            Debug.Log("🧹 VoiceButtonMinimal cleaned up safely");
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"Cleanup warning (non-critical): {e.Message}");
        }
    }
    
    #if UNITY_EDITOR
    [ContextMenu("Test - Toggle State")]
    void TestToggleState()
    {
        OnButtonClick();
    }
    
    [ContextMenu("Test - Force Reset")]
    void TestForceReset()
    {
        ForceReset();
    }
    
    [ContextMenu("Debug - Show State")]
    void DebugShowState()
    {
        Debug.Log($"=== VoiceButtonMinimal State ===");
        Debug.Log($"Is Recording: {isRecording}");
        Debug.Log($"Button: {(button != null ? "Found" : "NULL")}");
        Debug.Log($"Button Text: {(buttonText != null ? "Found" : "NULL")}");
        Debug.Log($"GameObject Active: {gameObject.activeInHierarchy}");
        
        if (button != null)
        {
            Debug.Log($"Button Interactable: {button.interactable}");
            Debug.Log($"Button Normal Color: {button.colors.normalColor}");
            Debug.Log($"Button Disabled Color: {button.colors.disabledColor}");
        }
    }
    
    [ContextMenu("Fix - Force Enable Button")]
    void ForceEnableButton()
    {
        if (button != null)
        {
            button.interactable = true;
            UpdateButtonVisuals();
            Debug.Log("🔧 Button force enabled and visuals updated");
        }
    }
    
    [ContextMenu("Fix - Reset Colors")]
    void ResetColors()
    {
        if (button != null)
        {
            ColorBlock colors = button.colors;
            colors.normalColor = isRecording ? recordingColor : idleColor;
            colors.highlightedColor = Color.white;
            colors.pressedColor = Color.gray;
            colors.selectedColor = colors.normalColor;
            colors.disabledColor = Color.gray;
            
            button.colors = colors;
            Debug.Log("🎨 Button colors reset");
        }
    }
    #endif
}

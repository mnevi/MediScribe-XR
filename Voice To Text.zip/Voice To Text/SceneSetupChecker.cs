using UnityEngine;
using Whisper.Utils;
using Whisper;

/// <summary>
/// Simple scene setup checker that validates the AR Voice Recognition setup
/// and helps prevent null reference exceptions.
/// </summary>
[System.Serializable]
public class SceneSetupChecker : MonoBehaviour
{
    [Header("Scene Setup Status")]
    [SerializeField] private bool sceneIsValid = false;
    [SerializeField] private string setupStatus = "Not Checked";
    [SerializeField] private int issuesFound = 0;
    
    [Header("Quick Fix")]
    [Tooltip("Automatically fix found issues")]
    public bool autoFix = true;
    
    [Header("One-Click Setup")]
    [Tooltip("Creates complete setup with one click")]
    public bool createCompleteSetup = false;
    
    void Start()
    {
        // Automatically check scene setup when component starts
        CheckSceneSetup();
        
        // If createCompleteSetup is enabled, auto-create everything
        if (createCompleteSetup)
        {
            CreateMissingComponents();
        }
    }
    
    [ContextMenu("Check Scene Setup")]
    public void CheckSceneSetup()
    {
        Debug.Log("🔍 CHECKING SCENE SETUP FOR AR VOICE RECOGNITION...");
        
        issuesFound = 0;
        bool allGood = true;
        
        // Check 1: ARVoiceRecognitionCore exists
        var voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
        if (voiceCore == null)
        {
            Debug.LogError("❌ No ARVoiceRecognitionCore found in scene!");
            Debug.LogError("   SOLUTION: Add ARVoiceRecognitionCore component to a GameObject");
            Debug.LogError("   OR: Click 'Create Missing Components' below to auto-create");
            issuesFound++;
            allGood = false;
        }
        else
        {
            Debug.Log("✅ ARVoiceRecognitionCore found");
            
            // Check its references
            if (voiceCore.whisperManager == null)
            {
                Debug.LogError("❌ ARVoiceRecognitionCore.whisperManager is not assigned!");
                issuesFound++;
                allGood = false;
                
                if (autoFix)
                {
                    var foundWhisperManager = FindFirstObjectByType<WhisperManager>();
                    if (foundWhisperManager != null)
                    {
                        voiceCore.whisperManager = foundWhisperManager;
                        Debug.Log("🔧 Auto-fixed: Assigned WhisperManager");
                        issuesFound--;
                    }
                }
            }
            else
            {
                Debug.Log("✅ WhisperManager assigned to ARVoiceRecognitionCore");
            }
            
            if (voiceCore.microphoneRecord == null)
            {
                Debug.LogError("❌ ARVoiceRecognitionCore.microphoneRecord is not assigned!");
                issuesFound++;
                allGood = false;
                
                if (autoFix)
                {
                    var foundMicrophoneRecord = FindFirstObjectByType<MicrophoneRecord>();
                    if (foundMicrophoneRecord != null)
                    {
                        voiceCore.microphoneRecord = foundMicrophoneRecord;
                        Debug.Log("🔧 Auto-fixed: Assigned MicrophoneRecord");
                        issuesFound--;
                    }
                }
            }
            else
            {
                Debug.Log("✅ MicrophoneRecord assigned to ARVoiceRecognitionCore");
            }
        }
        
        // Check 2: WhisperManager exists
        var whisperManager = FindFirstObjectByType<WhisperManager>();
        if (whisperManager == null)
        {
            Debug.LogError("❌ No WhisperManager found in scene!");
            Debug.LogError("   Add WhisperManager component to a GameObject");
            issuesFound++;
            allGood = false;
        }
        else
        {
            Debug.Log("✅ WhisperManager found");
        }
        
        // Check 3: MicrophoneRecord exists
        var microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
        if (microphoneRecord == null)
        {
            Debug.LogError("❌ No MicrophoneRecord found in scene!");
            Debug.LogError("   Add MicrophoneRecord component to a GameObject");
            issuesFound++;
            allGood = false;
        }
        else
        {
            Debug.Log("✅ MicrophoneRecord found");
        }
        
        // Check 4: UI Components (optional)
        var voiceEventHandler = FindFirstObjectByType<VoiceEventHandler>();
        if (voiceEventHandler != null)
        {
            Debug.Log("✅ VoiceEventHandler found (UI integration available)");
            
            if (voiceEventHandler.voiceCore == null && voiceCore != null && autoFix)
            {
                voiceEventHandler.voiceCore = voiceCore;
                Debug.Log("🔧 Auto-fixed: Assigned VoiceCore to VoiceEventHandler");
            }
        }
        else
        {
            Debug.Log("ℹ️ No VoiceEventHandler found (manual UI integration mode)");
        }
        
        // Update status
        sceneIsValid = allGood && issuesFound == 0;
        
        if (sceneIsValid)
        {
            setupStatus = "✅ Scene Setup Valid";
            Debug.Log("🎉 SCENE SETUP IS VALID! AR Voice Recognition should work correctly.");
        }
        else
        {
            setupStatus = $"❌ {issuesFound} Issues Found";
            Debug.LogWarning($"⚠️ SCENE SETUP HAS {issuesFound} ISSUES. Please fix them for proper operation.");
        }
        
        Debug.Log($"📊 Setup Status: {setupStatus}");
    }
    
    [ContextMenu("Create Missing Components")]
    public void CreateMissingComponents()
    {
        Debug.Log("🔧 Creating missing components...");
        
        // Create VoiceRecognitionManager GameObject if needed
        var voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
        GameObject voiceManagerGO = null;
        
        if (voiceCore == null)
        {
            voiceManagerGO = new GameObject("VoiceRecognitionManager");
            voiceCore = voiceManagerGO.AddComponent<ARVoiceRecognitionCore>();
            Debug.Log("🔧 Created VoiceRecognitionManager with ARVoiceRecognitionCore");
        }
        else
        {
            voiceManagerGO = voiceCore.gameObject;
        }
        
        // Add WhisperManager if missing
        var whisperManager = FindFirstObjectByType<WhisperManager>();
        if (whisperManager == null)
        {
            whisperManager = voiceManagerGO.AddComponent<WhisperManager>();
            voiceCore.whisperManager = whisperManager;
            Debug.Log("🔧 Created WhisperManager component");
        }
        
        // Add MicrophoneRecord if missing
        var microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
        if (microphoneRecord == null)
        {
            microphoneRecord = voiceManagerGO.AddComponent<MicrophoneRecord>();
            voiceCore.microphoneRecord = microphoneRecord;
            Debug.Log("🔧 Created MicrophoneRecord component");
        }
        
        Debug.Log("🔧 Missing components created. Re-checking setup...");
        CheckSceneSetup();
    }
    
    [ContextMenu("Show Setup Instructions")]
    public void ShowSetupInstructions()
    {
        Debug.Log("📋 AR VOICE RECOGNITION SETUP INSTRUCTIONS:");
        Debug.Log("1. Ensure these components exist in your scene:");
        Debug.Log("   - ARVoiceRecognitionCore (main logic)");
        Debug.Log("   - WhisperManager (speech recognition)");
        Debug.Log("   - MicrophoneRecord (audio input)");
        Debug.Log("");
        Debug.Log("2. Component assignment:");
        Debug.Log("   - ARVoiceRecognitionCore.whisperManager → WhisperManager component");
        Debug.Log("   - ARVoiceRecognitionCore.microphoneRecord → MicrophoneRecord component");
        Debug.Log("");
        Debug.Log("3. Optional UI integration:");
        Debug.Log("   - Add VoiceEventHandler for automatic UI updates");
        Debug.Log("   - Assign VoiceEventHandler.voiceCore → ARVoiceRecognitionCore component");
        Debug.Log("");
        Debug.Log("4. Use 'Create Missing Components' if you need automatic setup");
        Debug.Log("5. Use 'Check Scene Setup' to verify everything is correct");
    }
    
    void OnValidate()
    {
        // Update status when Inspector values change
        if (Application.isPlaying)
        {
            CheckSceneSetup();
        }
    }
}

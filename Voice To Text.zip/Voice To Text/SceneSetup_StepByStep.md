# AR Voice Recognition Scene Setup Guide

## The Problem
The diagnostic tool reports: "❌ ARVoiceRecognitionCore is NULL"

This means there's no ARVoiceRecognitionCore component in your scene, or it's not properly set up.

## Step-by-Step Solution

### Step 1: Create the Main Voice Recognition GameObject

1. **Create Main GameObject:**
   ```
   Right-click in Hierarchy → Create Empty
   Name it: "VoiceRecognitionManager"
   ```

2. **Add ARVoiceRecognitionCore Component:**
   ```
   Select "VoiceRecognitionManager"
   In Inspector → Add Component
   Search for "ARVoiceRecognitionCore"
   Add the component
   ```

### Step 2: Add Required Whisper Components

1. **Add WhisperManager:**
   ```
   Select "VoiceRecognitionManager" 
   In Inspector → Add Component
   Search for "WhisperManager"
   Add the component
   ```

2. **Add MicrophoneRecord:**
   ```
   Select "VoiceRecognitionManager"
   In Inspector → Add Component  
   Search for "MicrophoneRecord"
   Add the component
   ```

### Step 3: Configure Component References

1. **Assign WhisperManager:**
   ```
   Select "VoiceRecognitionManager"
   In ARVoiceRecognitionCore component:
   - Drag the same GameObject to "Whisper Manager" field
   ```

2. **Assign MicrophoneRecord:**
   ```
   In ARVoiceRecognitionCore component:
   - Drag the same GameObject to "Microphone Record" field
   ```

### Step 4: Use Automatic Setup (Recommended)

1. **Add SceneSetupChecker:**
   ```
   Right-click in Hierarchy → Create Empty
   Name it: "SceneValidator"
   Add Component → SceneSetupChecker
   ```

2. **Auto-Create Components:**
   ```
   In SceneSetupChecker Inspector:
   - Click "Create Missing Components"
   - Click "Check Scene Setup"
   ```

### Step 5: Verify Setup

1. **Run Diagnostics:**
   ```
   Add ARVoiceRecognitionDiagnostic component to any GameObject
   In Inspector, click "Run Full Diagnostics"
   Check Console for results
   ```

2. **Expected Result:**
   ```
   ✅ ARVoiceRecognitionCore found
   ✅ WhisperManager found
   ✅ MicrophoneRecord found
   🎉 SCENE SETUP IS VALID!
   ```

## Quick Auto-Setup Method

If you want everything created automatically:

1. **Create Setup GameObject:**
   ```
   Right-click in Hierarchy → Create Empty
   Name it: "AutoSetup"
   Add Component → SceneSetupChecker
   ```

2. **Auto-Create Everything:**
   ```
   In SceneSetupChecker Inspector:
   1. Click "Create Missing Components"
   2. Click "Check Scene Setup"
   3. Delete the "AutoSetup" GameObject when done
   ```

## Your Scene Structure Should Look Like:

```
Scene Hierarchy:
├── VoiceRecognitionManager
│   ├── ARVoiceRecognitionCore (Component)
│   ├── WhisperManager (Component)
│   └── MicrophoneRecord (Component)
├── Main Camera
├── Directional Light
└── Canvas (for UI - optional)
    └── UI elements with VoiceEventHandler
```

## Troubleshooting

### If Components Are Missing:
```
Problem: Can't find WhisperManager or MicrophoneRecord components
Solution: Ensure Whisper Unity package is properly imported
```

### If Auto-Assignment Fails:
```
Problem: References not automatically assigned
Solution: Manually drag components in Inspector
```

### If Still Getting Null Errors:
```
1. Delete all voice recognition GameObjects
2. Use SceneSetupChecker "Create Missing Components"
3. Verify all references are assigned
4. Enter Play Mode to test
```

## Testing Your Setup

1. **Enter Play Mode**
2. **Check Console Messages:**
   ```
   Should see:
   ✅ All components validated successfully
   🔍 [TIMER DEBUG] Starting initialization loop
   ✅ AR Voice Recognition fully initialized!
   ```

3. **If You See Errors:**
   ```
   - Exit Play Mode
   - Use diagnostic tools to identify issues
   - Follow error messages to fix problems
   ```

## Alternative: Manual Scene Setup

If automatic setup doesn't work:

1. **Create GameObject Manually:**
   ```csharp
   // In Inspector, create new script with this content:
   using UnityEngine;
   using Whisper;
   using Whisper.Utils;

   public class ManualSetup : MonoBehaviour
   {
       void Start()
       {
           // Create main voice recognition GameObject
           var voiceGO = new GameObject("VoiceRecognitionManager");
           
           // Add components
           var voiceCore = voiceGO.AddComponent<ARVoiceRecognitionCore>();
           var whisperManager = voiceGO.AddComponent<WhisperManager>();
           var microphoneRecord = voiceGO.AddComponent<MicrophoneRecord>();
           
           // Assign references
           voiceCore.whisperManager = whisperManager;
           voiceCore.microphoneRecord = microphoneRecord;
           
           Debug.Log("✅ Manual setup complete!");
       }
   }
   ```

The key is ensuring ARVoiceRecognitionCore exists in your scene with proper component references!

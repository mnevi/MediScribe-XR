using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

/// <summary>
/// Ultra-robust voice recognition button with enhanced crash prevention
/// This version includes maximum safety checks and detailed error reporting
/// </summary>
public class VoiceRecognitionButtonUltra : MonoBehaviour
{
    [Header("REQUIRED - Button Component")]
    [Tooltip("The UI Button component - this MUST be assigned")]
    public Button recordButton;
    
    [Header("TEXT COMPONENT - Choose ONE")]
    [Tooltip("For UI buttons, use TextMeshProUGUI (not TextMeshPro)")]
    public TextMeshProUGUI buttonTextTMP;
    
    [Tooltip("Legacy Unity Text component (if not using TextMeshPro)")]
    public Text buttonText;
    
    [Header("Button States")]
    public string idleText = "Record";
    public string recordingText = "Stop";
    public string processingText = "Processing...";
    public string errorText = "Error";
    
    [Header("Button Colors")]
    public Color idleColor = new Color(0.2f, 0.7f, 0.3f, 1f);      // Green
    public Color recordingColor = new Color(0.8f, 0.2f, 0.2f, 1f);  // Red
    public Color processingColor = new Color(0.8f, 0.6f, 0.2f, 1f); // Orange
    public Color errorColor = new Color(0.5f, 0.5f, 0.5f, 1f);      // Gray
    
    [Header("Core Component - AUTO-FOUND")]
    [Tooltip("ARVoiceRecognitionCore - will be auto-found if not assigned")]
    public ARVoiceRecognitionCore voiceRecognitionCore;
    
    [Header("Debug Settings")]
    [Tooltip("Enable detailed debug logging")]
    public bool enableDebugLogging = true;
    
    // Internal state tracking
    private bool isRecording = false;
    private bool isProcessing = false;
    private bool isInitialized = false;
    private bool hasValidComponents = false;
    
    // Component validation flags
    private bool hasButton = false;
    private bool hasTextComponent = false;
    private bool hasVoiceCore = false;
    
    // Error prevention
    private Coroutine safetyCheckCoroutine;
    private const float SAFETY_CHECK_INTERVAL = 1f;
    
    void Start()
    {
        LogDebug("🚀 VoiceRecognitionButtonUltra starting initialization...");
        
        try
        {
            ValidateAllComponents();
            
            if (hasValidComponents)
            {
                SetupButton();
                ConnectToVoiceRecognition();
                StartSafetyChecks();
                SetButtonState(ButtonState.Idle);
                isInitialized = true;
                LogDebug("✅ VoiceRecognitionButtonUltra initialized successfully!");
            }
            else
            {
                LogError("❌ Component validation failed - button will not function");
                LogError($"❌ Validation details - Button: {hasButton}, VoiceCore: {hasVoiceCore}, Text: {hasTextComponent}");
                SetButtonState(ButtonState.Error);
                isInitialized = false;
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Critical error during initialization: {e.Message}");
            LogError($"❌ Stack trace: {e.StackTrace}");
            SetButtonState(ButtonState.Error);
            isInitialized = false;
        }
    }
    
    void ValidateAllComponents()
    {
        LogDebug("🔍 Starting component validation...");
        
        // 1. Validate Button Component
        if (recordButton == null)
        {
            recordButton = GetComponent<Button>();
        }
        
        hasButton = (recordButton != null);
        if (!hasButton)
        {
            LogError("❌ CRITICAL: No Button component found! Please assign recordButton in the inspector or add a Button component to this GameObject.");
            return;
        }
        LogDebug("✅ Button component validated");
        
        // 2. Validate Text Component
        if (buttonTextTMP == null && buttonText == null)
        {
            // Try to auto-find text components
            buttonTextTMP = recordButton.GetComponentInChildren<TextMeshProUGUI>();
            buttonText = recordButton.GetComponentInChildren<Text>();
        }
        
        hasTextComponent = (buttonTextTMP != null || buttonText != null);
        if (!hasTextComponent)
        {
            LogError("⚠️ WARNING: No text component found. Button text changes will be skipped. Add a TextMeshProUGUI or Text component as a child of the button.");
        }
        else
        {
            string textType = buttonTextTMP != null ? "TextMeshProUGUI" : "Unity Text";
            LogDebug($"✅ Text component validated: {textType}");
        }
        
        // 3. Validate Voice Recognition Core
        if (voiceRecognitionCore == null)
        {
            voiceRecognitionCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
        }
        
        hasVoiceCore = (voiceRecognitionCore != null);
        if (!hasVoiceCore)
        {
            LogError("❌ CRITICAL: No ARVoiceRecognitionCore found! Please ensure there's an ARVoiceRecognitionCore component in the scene and assign it to this button.");
            return;
        }
        LogDebug("✅ ARVoiceRecognitionCore validated");
        
        // 4. Final validation
        hasValidComponents = hasButton && hasVoiceCore;
        
        LogDebug($"📊 Component validation summary:");
        LogDebug($"   Button: {(hasButton ? "✅" : "❌")}");
        LogDebug($"   Text: {(hasTextComponent ? "✅" : "⚠️")}");
        LogDebug($"   Voice Core: {(hasVoiceCore ? "✅" : "❌")}");
        LogDebug($"   Overall Valid: {(hasValidComponents ? "✅" : "❌")}");
    }
    
    void SetupButton()
    {
        if (!hasButton) return;
        
        try
        {
            // Clear any existing listeners to prevent duplicates
            recordButton.onClick.RemoveAllListeners();
            
            // Add our click handler
            recordButton.onClick.AddListener(OnButtonClick);
            
            LogDebug("✅ Button click handler attached");
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error setting up button: {e.Message}");
        }
    }
    
    void ConnectToVoiceRecognition()
    {
        if (!hasVoiceCore) return;
        
        try
        {
            // Subscribe to voice recognition events
            voiceRecognitionCore.OnRecordingStateChanged.AddListener(OnRecordingStateChanged);
            voiceRecognitionCore.OnStatusChanged.AddListener(OnStatusChanged);
            voiceRecognitionCore.OnErrorOccurred.AddListener(OnVoiceRecognitionError);
            
            LogDebug("✅ Voice recognition events connected");
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error connecting to voice recognition: {e.Message}");
        }
    }
    
    void StartSafetyChecks()
    {
        if (safetyCheckCoroutine != null)
        {
            StopCoroutine(safetyCheckCoroutine);
        }
        
        safetyCheckCoroutine = StartCoroutine(SafetyCheckLoop());
        LogDebug("✅ Safety check loop started");
    }
    
    IEnumerator SafetyCheckLoop()
    {
        while (this != null && gameObject != null)
        {
            // Check if components are still valid (outside try-catch to allow yield)
            if (recordButton == null || voiceRecognitionCore == null)
            {
                LogError("❌ Critical component became null during runtime!");
                SetButtonState(ButtonState.Error);
                yield break;
            }
            
            // Check if gameObject is still active
            if (!gameObject.activeInHierarchy)
            {
                yield return new WaitForSeconds(SAFETY_CHECK_INTERVAL);
                continue;
            }
            
            // Perform additional safety checks without yield inside try-catch
            try
            {
                // Additional validation that doesn't require yield
                if (isInitialized && hasValidComponents)
                {
                    // Validate state consistency
                    if (recordButton != null && !recordButton.gameObject.activeInHierarchy)
                    {
                        LogError("❌ Button became inactive during runtime!");
                        SetButtonState(ButtonState.Error);
                    }
                }
            }
            catch (System.Exception e)
            {
                LogError($"❌ Error in safety check validation: {e.Message}");
                // Don't yield break here, just log and continue
            }
            
            yield return new WaitForSeconds(SAFETY_CHECK_INTERVAL);
        }
    }
    
    void OnButtonClick()
    {
        LogDebug("🖱️ Button clicked!");
        
        // Multiple layers of safety checks
        if (!PreClickSafetyCheck())
        {
            LogError("❌ Pre-click safety check failed");
            return;
        }
        
        try
        {
            // Prevent clicks during processing (unless stopping recording)
            if (isProcessing && !isRecording)
            {
                LogDebug("⚠️ Button click ignored - system is processing");
                return;
            }
            
            // Call voice recognition toggle
            LogDebug($"🎤 Toggling voice recognition (currently recording: {isRecording})");
            voiceRecognitionCore.ToggleVoiceRecognition();
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error during button click: {e.Message}");
            LogError($"❌ Stack trace: {e.StackTrace}");
            SetButtonState(ButtonState.Error);
        }
    }
    
    bool PreClickSafetyCheck()
    {
        // Check if this component is still valid
        if (this == null)
        {
            LogError("❌ Button component is null");
            return false;
        }
        
        // Check if not initialized and provide more detailed info
        if (!isInitialized)
        {
            LogError($"❌ Button not initialized. HasValidComponents: {hasValidComponents}, HasButton: {hasButton}, HasVoiceCore: {hasVoiceCore}");
            
            // Try to re-initialize if we haven't tried yet
            if (!hasValidComponents)
            {
                LogDebug("🔄 Attempting re-initialization...");
                ValidateAllComponents();
                
                if (hasValidComponents && !isInitialized)
                {
                    SetupButton();
                    ConnectToVoiceRecognition();
                    isInitialized = true;
                    LogDebug("✅ Re-initialization successful!");
                    return true;
                }
            }
            return false;
        }
        
        // Check if gameObject is active
        if (gameObject == null || !gameObject.activeInHierarchy)
        {
            LogError("❌ Button gameObject is null or not active in hierarchy");
            return false;
        }
        
        // Check if button is still valid
        if (recordButton == null)
        {
            LogError("❌ Record button component is null");
            return false;
        }
        
        // Check if voice recognition core is still valid
        if (voiceRecognitionCore == null)
        {
            LogError("❌ Voice recognition core is null");
            return false;
        }
        
        LogDebug("✅ Pre-click safety check passed");
        return true;
    }
    
    void OnRecordingStateChanged(bool recording)
    {
        if (!isInitialized || !SafeStateChange()) return;
        
        try
        {
            isRecording = recording;
            LogDebug($"🎯 Recording state changed: {recording}");
            
            if (recording)
            {
                SetButtonState(ButtonState.Recording);
            }
            else
            {
                // Check if we should show processing state
                if (voiceRecognitionCore != null && voiceRecognitionCore.CurrentStatus.Contains("Processing"))
                {
                    SetButtonState(ButtonState.Processing);
                }
                else
                {
                    SetButtonState(ButtonState.Idle);
                }
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error handling recording state change: {e.Message}");
        }
    }
    
    void OnStatusChanged(string status)
    {
        if (!isInitialized || !SafeStateChange() || string.IsNullOrEmpty(status)) return;
        
        try
        {
            LogDebug($"📊 Status changed: {status}");
            
            bool wasProcessing = isProcessing;
            isProcessing = status.Contains("Processing") || status.Contains("Loading") || status.Contains("Creating");
            
            // Update button state if processing state changed and we're not recording
            if (wasProcessing != isProcessing && !isRecording)
            {
                SetButtonState(isProcessing ? ButtonState.Processing : ButtonState.Idle);
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error handling status change: {e.Message}");
        }
    }
    
    void OnVoiceRecognitionError(string error)
    {
        if (!isInitialized || !SafeStateChange()) return;
        
        try
        {
            LogError($"🚨 Voice recognition error: {error}");
            SetButtonState(ButtonState.Error);
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error handling voice recognition error: {e.Message}");
        }
    }
    
    bool SafeStateChange()
    {
        return (this != null && 
                gameObject != null && 
                gameObject.activeInHierarchy && 
                recordButton != null);
    }
    
    enum ButtonState
    {
        Idle,
        Recording,
        Processing,
        Error
    }
    
    void SetButtonState(ButtonState state)
    {
        if (!hasButton || !gameObject.activeInHierarchy) return;
        
        try
        {
            string text;
            Color color;
            bool interactable = true;
            
            switch (state)
            {
                case ButtonState.Recording:
                    text = recordingText;
                    color = recordingColor;
                    break;
                case ButtonState.Processing:
                    text = processingText;
                    color = processingColor;
                    interactable = false;
                    break;
                case ButtonState.Error:
                    text = errorText;
                    color = errorColor;
                    interactable = false;
                    break;
                default: // Idle
                    text = idleText;
                    color = idleColor;
                    break;
            }
            
            // Update button text (if text component exists)
            if (hasTextComponent)
            {
                UpdateButtonText(text);
            }
            
            // Update button interactability
            recordButton.interactable = interactable;
            
            // Update button color
            UpdateButtonColor(color);
            
            LogDebug($"🎨 Button state set to {state} - Text: '{text}', Interactable: {interactable}");
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error setting button state: {e.Message}");
        }
    }
    
    void UpdateButtonText(string text)
    {
        try
        {
            if (buttonTextTMP != null && buttonTextTMP.gameObject.activeInHierarchy)
            {
                buttonTextTMP.text = text;
            }
            else if (buttonText != null && buttonText.gameObject.activeInHierarchy)
            {
                buttonText.text = text;
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error updating button text: {e.Message}");
        }
    }
    
    void UpdateButtonColor(Color color)
    {
        try
        {
            if (recordButton == null || !recordButton.gameObject.activeInHierarchy) return;
            
            ColorBlock colors = recordButton.colors;
            colors.normalColor = color;
            colors.highlightedColor = Color.Lerp(color, Color.white, 0.2f);
            colors.pressedColor = Color.Lerp(color, Color.black, 0.2f);
            colors.disabledColor = Color.Lerp(color, Color.gray, 0.5f);
            
            recordButton.colors = colors;
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error updating button color: {e.Message}");
        }
    }
    
    // Public methods for manual control
    public void ResetToIdle()
    {
        if (!isInitialized) return;
        
        isRecording = false;
        isProcessing = false;
        SetButtonState(ButtonState.Idle);
        LogDebug("🔄 Button manually reset to idle");
    }
    
    public void ForceErrorState()
    {
        SetButtonState(ButtonState.Error);
        LogDebug("❌ Button forced to error state");
    }
    
    /// <summary>
    /// Force re-initialization of the button component
    /// </summary>
    public void ForceReinitialize()
    {
        LogDebug("🔄 Force re-initializing button...");
        
        try
        {
            // Reset all state
            isInitialized = false;
            hasValidComponents = false;
            hasButton = false;
            hasTextComponent = false;
            hasVoiceCore = false;
            
            // Stop existing safety checks
            if (safetyCheckCoroutine != null)
            {
                StopCoroutine(safetyCheckCoroutine);
                safetyCheckCoroutine = null;
            }
            
            // Re-run initialization
            ValidateAllComponents();
            
            if (hasValidComponents)
            {
                SetupButton();
                ConnectToVoiceRecognition();
                StartSafetyChecks();
                SetButtonState(ButtonState.Idle);
                isInitialized = true;
                LogDebug("✅ Force re-initialization successful!");
            }
            else
            {
                LogError("❌ Force re-initialization failed - components still invalid");
                SetButtonState(ButtonState.Error);
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error during force re-initialization: {e.Message}");
            SetButtonState(ButtonState.Error);
        }
    }
    
    // Status properties
    public bool IsRecording => isRecording;
    public bool IsProcessing => isProcessing;
    public bool IsInitialized => isInitialized;
    public bool HasValidComponents => hasValidComponents;
    
    void LogDebug(string message)
    {
        if (enableDebugLogging)
        {
            Debug.Log($"[VoiceButtonUltra] {message}");
        }
    }
    
    void LogError(string message)
    {
        Debug.LogError($"[VoiceButtonUltra] {message}");
    }
    
    void OnDestroy()
    {
        try
        {
            LogDebug("🧹 Cleaning up VoiceRecognitionButtonUltra...");
            
            // Stop safety checks
            if (safetyCheckCoroutine != null)
            {
                StopCoroutine(safetyCheckCoroutine);
                safetyCheckCoroutine = null;
            }
            
            // Clean up voice recognition events
            if (voiceRecognitionCore != null)
            {
                try
                {
                    voiceRecognitionCore.OnRecordingStateChanged.RemoveListener(OnRecordingStateChanged);
                    voiceRecognitionCore.OnStatusChanged.RemoveListener(OnStatusChanged);
                    voiceRecognitionCore.OnErrorOccurred.RemoveListener(OnVoiceRecognitionError);
                }
                catch (System.Exception e)
                {
                    LogError($"Warning: Error removing voice recognition listeners: {e.Message}");
                }
            }
            
            // Clean up button events
            if (recordButton != null)
            {
                try
                {
                    recordButton.onClick.RemoveListener(OnButtonClick);
                }
                catch (System.Exception e)
                {
                    LogError($"Warning: Error removing button listener: {e.Message}");
                }
            }
            
            LogDebug("✅ Cleanup completed");
        }
        catch (System.Exception e)
        {
            LogError($"Error during cleanup: {e.Message}");
        }
    }
    
    #if UNITY_EDITOR
    [ContextMenu("Debug - Validate Components")]
    void DebugValidateComponents()
    {
        ValidateAllComponents();
        Debug.Log($"Component validation result: {(hasValidComponents ? "PASSED" : "FAILED")}");
        Debug.Log($"Detailed results - Button: {hasButton}, Text: {hasTextComponent}, VoiceCore: {hasVoiceCore}");
    }
    
    [ContextMenu("Debug - Force Reinitialize")]
    void DebugForceReinitialize()
    {
        ForceReinitialize();
    }
    
    [ContextMenu("Debug - Show Current State")]
    void DebugShowCurrentState()
    {
        Debug.Log($"=== VoiceRecognitionButtonUltra State ===");
        Debug.Log($"Initialized: {isInitialized}");
        Debug.Log($"Recording: {isRecording}");
        Debug.Log($"Processing: {isProcessing}");
        Debug.Log($"Has Valid Components: {hasValidComponents}");
        Debug.Log($"Has Button: {hasButton}");
        Debug.Log($"Has Text Component: {hasTextComponent}");
        Debug.Log($"Has Voice Core: {hasVoiceCore}");
        Debug.Log($"Record Button: {(recordButton != null ? "Found" : "NULL")}");
        Debug.Log($"Button Text TMP: {(buttonTextTMP != null ? "Found" : "NULL")}");
        Debug.Log($"Button Text: {(buttonText != null ? "Found" : "NULL")}");
        Debug.Log($"Voice Recognition Core: {(voiceRecognitionCore != null ? "Found" : "NULL")}");
        Debug.Log($"GameObject Active: {(gameObject != null ? gameObject.activeInHierarchy.ToString() : "NULL")}");
    }
    
    [ContextMenu("Debug - Test Idle State")]
    void DebugTestIdle()
    {
        SetButtonState(ButtonState.Idle);
    }
    
    [ContextMenu("Debug - Test Recording State")]
    void DebugTestRecording()
    {
        SetButtonState(ButtonState.Recording);
    }
    
    [ContextMenu("Debug - Test Processing State")]
    void DebugTestProcessing()
    {
        SetButtonState(ButtonState.Processing);
    }
    
    [ContextMenu("Debug - Test Error State")]
    void DebugTestError()
    {
        SetButtonState(ButtonState.Error);
    }
    
    [ContextMenu("Debug - Force Safety Check")]
    void DebugSafetyCheck()
    {
        Debug.Log("=== Pre-Click Safety Check ===");
        bool result = PreClickSafetyCheck();
        Debug.Log($"Safety check result: {(result ? "PASSED" : "FAILED")}");
        
        if (!result)
        {
            Debug.Log("=== Additional Debug Info ===");
            Debug.Log($"This component null: {(this == null)}");
            Debug.Log($"Is initialized: {isInitialized}");
            Debug.Log($"GameObject null: {(gameObject == null)}");
            Debug.Log($"GameObject active: {(gameObject != null ? gameObject.activeInHierarchy.ToString() : "NULL")}");
            Debug.Log($"Record button null: {(recordButton == null)}");
            Debug.Log($"Voice core null: {(voiceRecognitionCore == null)}");
        }
    }
    #endif
}

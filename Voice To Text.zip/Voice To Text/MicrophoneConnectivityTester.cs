using UnityEngine;
using System.Collections;
using System.Linq;

/// <summary>
/// Microphone Connectivity Tester - Diagnoses microphone issues
/// Use this to check if microphone problems are causing voice recognition crashes
/// </summary>
public class MicrophoneConnectivityTester : MonoBehaviour
{
    [Header("Microphone Test Settings")]
    [Tooltip("Enable detailed debug logging")]
    public bool enableDebugLogging = true;
    
    [Tooltip("Test recording duration in seconds")]
    [Range(1f, 10f)]
    public float testDuration = 3f;
    
    [Tooltip("Minimum audio level to consider microphone working")]
    [Range(0.001f, 0.1f)]
    public float minimumAudioLevel = 0.01f;
    
    [Header("Test Results (Read-Only)")]
    [SerializeField] private bool hasMicrophones = false;
    [SerializeField] private bool canStartRecording = false;
    [SerializeField] private bool receivingAudioData = false;
    [SerializeField] private bool hasPermissions = false;
    [SerializeField] private string lastTestResult = "Not tested";
    [SerializeField] private float lastAudioLevel = 0f;
    
    // Internal state
    private AudioClip testClip;
    private bool isTestingMicrophone = false;
    private string[] availableDevices;
    private int testSampleRate = 44100;
    
    void Start()
    {
        if (enableDebugLogging)
        {
            LogDebug("🎙️ MicrophoneConnectivityTester ready. Use context menu or call TestMicrophoneConnectivity() to run tests.");
        }
    }
    
    /// <summary>
    /// Comprehensive microphone connectivity test
    /// </summary>
    public void TestMicrophoneConnectivity()
    {
        if (isTestingMicrophone)
        {
            LogDebug("⚠️ Test already in progress");
            return;
        }
        
        StartCoroutine(RunMicrophoneTests());
    }
    
    IEnumerator RunMicrophoneTests()
    {
        isTestingMicrophone = true;
        LogDebug("🧪 Starting comprehensive microphone connectivity tests...");
        
        // Reset test results
        hasMicrophones = false;
        canStartRecording = false;
        receivingAudioData = false;
        hasPermissions = false;
        lastTestResult = "Testing...";
        lastAudioLevel = 0f;
        
        bool testsFailed = false;
        
        // Test 1: Check if microphones are available
        yield return StartCoroutine(TestMicrophoneAvailability());
        
        if (!hasMicrophones)
        {
            lastTestResult = "FAILED: No microphones detected";
            LogError("❌ Test failed: No microphones available");
            testsFailed = true;
        }
        
        // Test 2: Check permissions and basic recording
        if (!testsFailed)
        {
            yield return StartCoroutine(TestMicrophonePermissions());
            
            if (!hasPermissions || !canStartRecording)
            {
                lastTestResult = "FAILED: Permission denied or cannot start recording";
                LogError("❌ Test failed: Cannot start microphone recording");
                testsFailed = true;
            }
        }
        
        // Test 3: Test actual audio data reception
        if (!testsFailed)
        {
            yield return StartCoroutine(TestAudioDataReception());
            
            if (!receivingAudioData)
            {
                lastTestResult = "FAILED: No audio data received";
                LogError("❌ Test failed: Microphone not receiving audio data");
                testsFailed = true;
            }
        }
        
        // Set final result
        if (!testsFailed)
        {
            lastTestResult = $"SUCCESS: Microphone working (Level: {lastAudioLevel:F4})";
            LogDebug($"✅ All microphone tests passed! Audio level: {lastAudioLevel:F4}");
        }
        
        // Clean up
        if (testClip != null && Microphone.IsRecording(null))
        {
            try
            {
                Microphone.End(null);
            }
            catch (System.Exception e)
            {
                LogError($"Warning: Error stopping test recording: {e.Message}");
            }
        }
        
        isTestingMicrophone = false;
    }
    
    IEnumerator TestMicrophoneAvailability()
    {
        LogDebug("🔍 Test 1: Checking microphone availability...");
        
        try
        {
            availableDevices = Microphone.devices;
            hasMicrophones = (availableDevices != null && availableDevices.Length > 0);
            
            if (hasMicrophones)
            {
                LogDebug($"✅ Found {availableDevices.Length} microphone device(s):");
                for (int i = 0; i < availableDevices.Length; i++)
                {
                    string deviceName = string.IsNullOrEmpty(availableDevices[i]) ? "[Default Device]" : availableDevices[i];
                    LogDebug($"   Device {i}: {deviceName}");
                }
            }
            else
            {
                LogError("❌ No microphone devices found");
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error checking microphone devices: {e.Message}");
            hasMicrophones = false;
        }
        
        yield return null;
    }
    
    IEnumerator TestMicrophonePermissions()
    {
        LogDebug("🔐 Test 2: Checking microphone permissions and basic recording...");
        
        bool permissionTestSucceeded = false;
        
        // Try to start a very short recording to test permissions
        string deviceToTest = availableDevices.Length > 0 ? availableDevices[0] : null;
        
        // Use null for default device if the first device name is empty
        if (string.IsNullOrEmpty(deviceToTest))
        {
            deviceToTest = null;
        }
        
        LogDebug($"🎙️ Testing device: {(deviceToTest ?? "[Default]")}");
        
        // Try to start recording
        try
        {
            testClip = Microphone.Start(deviceToTest, false, 1, testSampleRate);
            
            if (testClip != null)
            {
                hasPermissions = true;
                canStartRecording = true;
                LogDebug("✅ Successfully started test recording");
                permissionTestSucceeded = true;
            }
            else
            {
                hasPermissions = false;
                canStartRecording = false;
                LogError("❌ Failed to start test recording - permissions may be denied");
            }
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error testing microphone permissions: {e.Message}");
            hasPermissions = false;
            canStartRecording = false;
        }
        
        if (permissionTestSucceeded)
        {
            // Wait a moment then stop
            yield return new WaitForSeconds(0.5f);
            
            if (Microphone.IsRecording(deviceToTest))
            {
                try
                {
                    Microphone.End(deviceToTest);
                    LogDebug("✅ Successfully stopped test recording");
                }
                catch (System.Exception e)
                {
                    LogError($"❌ Error stopping test recording: {e.Message}");
                }
            }
        }
        
        yield return null;
    }
    
    IEnumerator TestAudioDataReception()
    {
        LogDebug("🎵 Test 3: Testing audio data reception...");
        
        string deviceToTest = availableDevices.Length > 0 ? availableDevices[0] : null;
        if (string.IsNullOrEmpty(deviceToTest))
        {
            deviceToTest = null;
        }
        
        bool audioTestSucceeded = false;
        
        // Start recording for the test duration
        try
        {
            testClip = Microphone.Start(deviceToTest, false, Mathf.CeilToInt(testDuration), testSampleRate);
            
            if (testClip == null)
            {
                LogError("❌ Could not start audio data test recording");
                receivingAudioData = false;
                yield break;
            }
            
            audioTestSucceeded = true;
        }
        catch (System.Exception e)
        {
            LogError($"❌ Error starting audio data test: {e.Message}");
            receivingAudioData = false;
            yield break;
        }
        
        if (audioTestSucceeded)
        {
            LogDebug($"🎙️ Recording for {testDuration} seconds to test audio data...");
            LogDebug("💬 Make some noise near the microphone!");
            
            float maxLevel = 0f;
            float testStartTime = Time.realtimeSinceStartup;
            
            // Monitor audio levels during recording
            while (Time.realtimeSinceStartup - testStartTime < testDuration)
            {
                if (Microphone.IsRecording(deviceToTest))
                {
                    try
                    {
                        float currentLevel = GetCurrentAudioLevel(testClip, deviceToTest);
                        maxLevel = Mathf.Max(maxLevel, currentLevel);
                        
                        // Log audio level every second
                        if (Mathf.FloorToInt(Time.realtimeSinceStartup - testStartTime) != 
                            Mathf.FloorToInt(Time.realtimeSinceStartup - testStartTime - Time.deltaTime))
                        {
                            LogDebug($"📊 Audio level: {currentLevel:F4} (max so far: {maxLevel:F4})");
                        }
                    }
                    catch (System.Exception e)
                    {
                        LogError($"❌ Error monitoring audio level: {e.Message}");
                    }
                }
                
                yield return null;
            }
            
            // Stop recording
            if (Microphone.IsRecording(deviceToTest))
            {
                try
                {
                    Microphone.End(deviceToTest);
                }
                catch (System.Exception e)
                {
                    LogError($"❌ Error stopping audio test recording: {e.Message}");
                }
            }
            
            lastAudioLevel = maxLevel;
            receivingAudioData = (maxLevel > minimumAudioLevel);
            
            if (receivingAudioData)
            {
                LogDebug($"✅ Audio data received! Max level: {maxLevel:F4}");
            }
            else
            {
                LogError($"❌ No significant audio detected. Max level: {maxLevel:F4}, Required: {minimumAudioLevel:F4}");
                LogError("💡 Try speaking louder or check if microphone is muted/disconnected");
            }
        }
    }
    
    float GetCurrentAudioLevel(AudioClip clip, string device)
    {
        if (clip == null) return 0f;
        
        try
        {
            int currentPosition = Microphone.GetPosition(device);
            if (currentPosition <= 0) return 0f;
            
            // Get the last 1024 samples to check current level
            int sampleCount = Mathf.Min(1024, currentPosition);
            int startPosition = Mathf.Max(0, currentPosition - sampleCount);
            
            float[] samples = new float[sampleCount];
            clip.GetData(samples, startPosition);
            
            // Calculate RMS (Root Mean Square) for audio level
            float sum = 0f;
            for (int i = 0; i < samples.Length; i++)
            {
                sum += samples[i] * samples[i];
            }
            
            return Mathf.Sqrt(sum / samples.Length);
        }
        catch (System.Exception e)
        {
            LogError($"Error calculating audio level: {e.Message}");
            return 0f;
        }
    }
    
    /// <summary>
    /// Quick microphone check - returns true if microphone appears to be working
    /// </summary>
    public bool QuickMicrophoneCheck()
    {
        try
        {
            // Check if devices are available
            string[] devices = Microphone.devices;
            if (devices == null || devices.Length == 0)
            {
                LogError("❌ Quick check: No microphone devices found");
                return false;
            }
            
            // Try to start a very brief recording
            AudioClip quickTest = Microphone.Start(null, false, 1, 22050);
            if (quickTest == null)
            {
                LogError("❌ Quick check: Cannot start microphone recording");
                return false;
            }
            
            // Stop immediately
            Microphone.End(null);
            
            LogDebug("✅ Quick check: Microphone appears to be working");
            return true;
        }
        catch (System.Exception e)
        {
            LogError($"❌ Quick check failed: {e.Message}");
            return false;
        }
    }
    
    /// <summary>
    /// Get detailed microphone information
    /// </summary>
    public string GetMicrophoneInfo()
    {
        try
        {
            string[] devices = Microphone.devices;
            
            if (devices == null || devices.Length == 0)
            {
                return "No microphone devices detected";
            }
            
            string info = $"Microphone Devices ({devices.Length}):\n";
            
            for (int i = 0; i < devices.Length; i++)
            {
                string deviceName = string.IsNullOrEmpty(devices[i]) ? "[Default Device]" : devices[i];
                
                // Try to get device capabilities
                int minFreq, maxFreq;
                Microphone.GetDeviceCaps(devices[i], out minFreq, out maxFreq);
                
                info += $"  {i}: {deviceName}\n";
                info += $"     Frequency range: {minFreq}Hz - {maxFreq}Hz\n";
            }
            
            return info;
        }
        catch (System.Exception e)
        {
            return $"Error getting microphone info: {e.Message}";
        }
    }
    
    // Public properties for external checking
    public bool HasMicrophones => hasMicrophones;
    public bool CanStartRecording => canStartRecording;
    public bool IsReceivingAudioData => receivingAudioData;
    public bool HasPermissions => hasPermissions;
    public string LastTestResult => lastTestResult;
    public float LastAudioLevel => lastAudioLevel;
    public bool IsTestingMicrophone => isTestingMicrophone;
    
    void LogDebug(string message)
    {
        if (enableDebugLogging)
        {
            Debug.Log($"[MicTest] {message}");
        }
    }
    
    void LogError(string message)
    {
        Debug.LogError($"[MicTest] {message}");
    }
    
    void OnDestroy()
    {
        // Clean up any ongoing recording
        if (testClip != null && Microphone.IsRecording(null))
        {
            try
            {
                Microphone.End(null);
            }
            catch (System.Exception e)
            {
                LogError($"Error stopping microphone on destroy: {e.Message}");
            }
        }
    }
    
    #if UNITY_EDITOR
    [ContextMenu("Test Microphone Connectivity")]
    void MenuTestMicrophoneConnectivity()
    {
        TestMicrophoneConnectivity();
    }
    
    [ContextMenu("Quick Microphone Check")]
    void MenuQuickMicrophoneCheck()
    {
        bool result = QuickMicrophoneCheck();
        Debug.Log($"Quick microphone check result: {(result ? "PASSED" : "FAILED")}");
    }
    
    [ContextMenu("Show Microphone Info")]
    void MenuShowMicrophoneInfo()
    {
        Debug.Log("=== MICROPHONE INFO ===");
        Debug.Log(GetMicrophoneInfo());
    }
    
    [ContextMenu("Show Test Results")]
    void MenuShowTestResults()
    {
        Debug.Log("=== MICROPHONE TEST RESULTS ===");
        Debug.Log($"Has Microphones: {hasMicrophones}");
        Debug.Log($"Has Permissions: {hasPermissions}");
        Debug.Log($"Can Start Recording: {canStartRecording}");
        Debug.Log($"Receiving Audio Data: {receivingAudioData}");
        Debug.Log($"Last Test Result: {lastTestResult}");
        Debug.Log($"Last Audio Level: {lastAudioLevel:F4}");
        Debug.Log($"Currently Testing: {isTestingMicrophone}");
    }
    #endif
}

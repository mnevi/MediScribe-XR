using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Crash Isolation Test - Helps identify exactly what causes the crash
/// This script tests each component individually to find the crash source
/// </summary>
public class CrashIsolationTest : MonoBehaviour
{
    [Header("Test Components")]
    public Button testButton;
    public TextMeshProUGUI testText;
    
    [Header("Test Controls")]
    [Tooltip("Enable to test basic button functionality")]
    public bool testBasicButton = true;
    
    [Tooltip("Enable to test text changes")]
    public bool testTextChanges = true;
    
    [Tooltip("Enable to test color changes")]
    public bool testColorChanges = true;
    
    [Tooltip("Enable to test finding ARVoiceRecognitionCore")]
    public bool testFindVoiceCore = false;
    
    [Tooltip("Enable to test calling voice recognition")]
    public bool testCallVoiceRecognition = false;
    
    private bool isToggled = false;
    
    void Start()
    {
        Debug.Log("🧪 CRASH ISOLATION TEST STARTED");
        Debug.Log("🧪 Click the button to test each component individually");
        
        InitializeTest();
    }
    
    void InitializeTest()
    {
        try
        {
            // Auto-find components
            if (testButton == null)
            {
                testButton = GetComponent<Button>();
            }
            
            if (testText == null)
            {
                testText = GetComponentInChildren<TextMeshProUGUI>();
            }
            
            // Setup button if available
            if (testButton != null && testBasicButton)
            {
                testButton.onClick.RemoveAllListeners();
                testButton.onClick.AddListener(RunIsolationTest);
                Debug.Log("✅ Test button setup complete");
            }
            else
            {
                Debug.LogError("❌ No button found for testing");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ CRASH IN INITIALIZATION: {e.Message}");
            Debug.LogError($"❌ Stack trace: {e.StackTrace}");
        }
    }
    
    void RunIsolationTest()
    {
        Debug.Log("🧪 ======= CRASH ISOLATION TEST SEQUENCE =======");
        
        try
        {
            // Test 1: Basic state toggle
            Debug.Log("🧪 Test 1: Basic state toggle");
            isToggled = !isToggled;
            Debug.Log($"✅ Test 1 PASSED - State toggled to: {isToggled}");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ CRASH IN TEST 1 (Basic Toggle): {e.Message}");
            return;
        }
        
        if (testTextChanges)
        {
            try
            {
                // Test 2: Text changes
                Debug.Log("🧪 Test 2: Text changes");
                if (testText != null)
                {
                    testText.text = isToggled ? "🔴 STOP" : "🎤 RECORD";
                    Debug.Log("✅ Test 2 PASSED - Text updated successfully");
                }
                else
                {
                    Debug.Log("⚠️ Test 2 SKIPPED - No text component");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ CRASH IN TEST 2 (Text Changes): {e.Message}");
                return;
            }
        }
        
        if (testColorChanges)
        {
            try
            {
                // Test 3: Color changes
                Debug.Log("🧪 Test 3: Color changes");
                if (testButton != null)
                {
                    ColorBlock colors = testButton.colors;
                    colors.normalColor = isToggled ? Color.red : Color.green;
                    testButton.colors = colors;
                    Debug.Log("✅ Test 3 PASSED - Color updated successfully");
                }
                else
                {
                    Debug.Log("⚠️ Test 3 SKIPPED - No button component");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ CRASH IN TEST 3 (Color Changes): {e.Message}");
                return;
            }
        }
        
        if (testFindVoiceCore)
        {
            try
            {
                // Test 4: Find voice recognition component
                Debug.Log("🧪 Test 4: Finding ARVoiceRecognitionCore");
                ARVoiceRecognitionCore voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
                
                if (voiceCore != null)
                {
                    Debug.Log("✅ Test 4 PASSED - ARVoiceRecognitionCore found");
                    Debug.Log($"✅ Voice Core GameObject: {voiceCore.gameObject.name}");
                    Debug.Log($"✅ Voice Core Enabled: {voiceCore.enabled}");
                }
                else
                {
                    Debug.Log("⚠️ Test 4 RESULT - No ARVoiceRecognitionCore found in scene");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ CRASH IN TEST 4 (Find Voice Core): {e.Message}");
                return;
            }
        }
        
        if (testCallVoiceRecognition)
        {
            try
            {
                // Test 5: Call voice recognition (DANGEROUS - This is likely where crash happens)
                Debug.Log("🧪 Test 5: Calling voice recognition (CRASH RISK)");
                ARVoiceRecognitionCore voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
                
                if (voiceCore != null)
                {
                    Debug.Log("🧪 About to call ToggleVoiceRecognition...");
                    voiceCore.ToggleVoiceRecognition();
                    Debug.Log("✅ Test 5 PASSED - Voice recognition called successfully");
                }
                else
                {
                    Debug.Log("⚠️ Test 5 SKIPPED - No voice core found");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ CRASH IN TEST 5 (Voice Recognition Call): {e.Message}");
                Debug.LogError($"❌ Stack trace: {e.StackTrace}");
                return;
            }
        }
        
        Debug.Log("✅ ======= ALL ENABLED TESTS PASSED =======");
    }
    
    #if UNITY_EDITOR
    [ContextMenu("Run Test Sequence")]
    void DebugRunTest()
    {
        RunIsolationTest();
    }
    
    [ContextMenu("Enable All Tests")]
    void EnableAllTests()
    {
        testBasicButton = true;
        testTextChanges = true;
        testColorChanges = true;
        testFindVoiceCore = true;
        testCallVoiceRecognition = true;
        Debug.Log("🧪 All tests enabled - CAUTION: Test 5 may crash");
    }
    
    [ContextMenu("Safe Tests Only")]
    void SafeTestsOnly()
    {
        testBasicButton = true;
        testTextChanges = true;
        testColorChanges = true;
        testFindVoiceCore = true;
        testCallVoiceRecognition = false;
        Debug.Log("🧪 Safe tests enabled - voice recognition disabled");
    }
    #endif
}

using UnityEngine;
using Whisper.Utils;
using Whisper;

/// <summary>
/// Diagnostic script to identify and fix null reference issues in ARVoiceRecognitionCore
/// This will help track down the source of Unity Editor Inspector errors
/// </summary>
public class ARVoiceRecognitionDiagnostic : MonoBehaviour
{
    [Header("Component References to Check")]
    public ARVoiceRecognitionCore voiceCore;
    public WhisperManager whisperManager;
    public MicrophoneRecord microphoneRecord;
    
    [Header("Diagnostic Results (Read Only)")]
    public bool voiceCoreValid;
    public bool whisperManagerValid;
    public bool microphoneRecordValid;
    public bool whisperManagerLoaded;
    public string diagnosticStatus;
    
    [Header("Auto-Fix Options")]
    [Tooltip("Automatically find and assign missing components")]
    public bool autoFindComponents = true;
    
    void Start()
    {
        RunDiagnostics();
        
        if (autoFindComponents)
        {
            AutoAssignMissingComponents();
        }
    }
    
    void Update()
    {
        // Continuously monitor component states
        UpdateDiagnosticStatus();
    }
    
    [ContextMenu("Run Full Diagnostics")]
    public void RunDiagnostics()
    {
        Debug.Log("🔍 RUNNING AR VOICE RECOGNITION DIAGNOSTICS...");
        
        CheckVoiceCore();
        CheckWhisperManager();
        CheckMicrophoneRecord();
        CheckInspectorReferences();
        CheckGameObjectStates();
        
        Debug.Log($"🔍 Diagnostic Status: {diagnosticStatus}");
    }
    
    private void CheckVoiceCore()
    {
        // Try to auto-find ARVoiceRecognitionCore if not assigned
        if (voiceCore == null)
        {
            voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
            if (voiceCore != null)
            {
                Debug.Log("🔧 Auto-found ARVoiceRecognitionCore in scene");
            }
        }
        
        voiceCoreValid = voiceCore != null;
        
        if (!voiceCoreValid)
        {
            Debug.LogError("❌ ARVoiceRecognitionCore is NULL");
            Debug.LogError("   No ARVoiceRecognitionCore component found in scene!");
            Debug.LogError("   Please add ARVoiceRecognitionCore component to a GameObject");
            diagnosticStatus = "VoiceCore Missing";
            return;
        }
        
        Debug.Log("✅ ARVoiceRecognitionCore found");
        
        // Check VoiceCore's internal references
        var coreWhisperManager = voiceCore.whisperManager;
        var coreMicrophoneRecord = voiceCore.microphoneRecord;
        
        if (coreWhisperManager == null)
        {
            Debug.LogError("❌ VoiceCore.whisperManager is NULL");
            diagnosticStatus = "VoiceCore WhisperManager Missing";
        }
        
        if (coreMicrophoneRecord == null)
        {
            Debug.LogError("❌ VoiceCore.microphoneRecord is NULL");
            diagnosticStatus = "VoiceCore MicrophoneRecord Missing";
        }
        
        if (coreWhisperManager != null && coreMicrophoneRecord != null)
        {
            Debug.Log("✅ VoiceCore has all required references");
        }
    }
    
    private void CheckWhisperManager()
    {
        whisperManagerValid = whisperManager != null;
        
        if (!whisperManagerValid)
        {
            Debug.LogError("❌ WhisperManager is NULL");
            
            // Try to find it in the scene
            whisperManager = FindFirstObjectByType<WhisperManager>();
            if (whisperManager != null)
            {
                Debug.Log("🔧 Found WhisperManager in scene, auto-assigning");
                whisperManagerValid = true;
            }
            else
            {
                Debug.LogError("❌ No WhisperManager found in scene!");
                diagnosticStatus = "WhisperManager Not Found";
                return;
            }
        }
        
        Debug.Log("✅ WhisperManager found");
        
        // Check WhisperManager state
        whisperManagerLoaded = whisperManager.IsLoaded;
        Debug.Log($"📊 WhisperManager IsLoaded: {whisperManagerLoaded}");
        
        if (!whisperManagerLoaded)
        {
            Debug.LogWarning("⚠️ WhisperManager not yet loaded - this is normal during startup");
        }
    }
    
    private void CheckMicrophoneRecord()
    {
        microphoneRecordValid = microphoneRecord != null;
        
        if (!microphoneRecordValid)
        {
            Debug.LogError("❌ MicrophoneRecord is NULL");
            
            // Try to find it in the scene
            microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
            if (microphoneRecord != null)
            {
                Debug.Log("🔧 Found MicrophoneRecord in scene, auto-assigning");
                microphoneRecordValid = true;
            }
            else
            {
                Debug.LogError("❌ No MicrophoneRecord found in scene!");
                diagnosticStatus = "MicrophoneRecord Not Found";
                return;
            }
        }
        
        Debug.Log("✅ MicrophoneRecord found");
        
        // Check MicrophoneRecord state
        if (microphoneRecord.IsRecording)
        {
            Debug.Log("📊 MicrophoneRecord is currently recording");
        }
        else
        {
            Debug.Log("📊 MicrophoneRecord is not recording");
        }
    }
    
    private void CheckInspectorReferences()
    {
        Debug.Log("🔍 Checking Inspector reference assignments...");
        
        if (voiceCore != null)
        {
#if UNITY_EDITOR
            var serializedObject = new UnityEditor.SerializedObject(voiceCore);
            
            var whisperManagerProp = serializedObject.FindProperty("whisperManager");
            var microphoneRecordProp = serializedObject.FindProperty("microphoneRecord");
            
            if (whisperManagerProp.objectReferenceValue == null)
            {
                Debug.LogError("❌ Inspector: whisperManager reference is null");
            }
            else
            {
                Debug.Log("✅ Inspector: whisperManager reference assigned");
            }
            
            if (microphoneRecordProp.objectReferenceValue == null)
            {
                Debug.LogError("❌ Inspector: microphoneRecord reference is null");
            }
            else
            {
                Debug.Log("✅ Inspector: microphoneRecord reference assigned");
            }
#else
            Debug.Log("⚠️ Inspector reference checking only available in Unity Editor");
            
            // Basic runtime checks instead
            if (voiceCore.whisperManager == null)
            {
                Debug.LogError("❌ Runtime: whisperManager reference is null");
            }
            else
            {
                Debug.Log("✅ Runtime: whisperManager reference assigned");
            }
            
            if (voiceCore.microphoneRecord == null)
            {
                Debug.LogError("❌ Runtime: microphoneRecord reference is null");
            }
            else
            {
                Debug.Log("✅ Runtime: microphoneRecord reference assigned");
            }
#endif
        }
    }
    
    private void CheckGameObjectStates()
    {
        Debug.Log("🔍 Checking GameObject states...");
        
        if (voiceCore != null)
        {
            Debug.Log($"📊 VoiceCore GameObject active: {voiceCore.gameObject.activeInHierarchy}");
            Debug.Log($"📊 VoiceCore enabled: {voiceCore.enabled}");
        }
        
        if (whisperManager != null)
        {
            Debug.Log($"📊 WhisperManager GameObject active: {whisperManager.gameObject.activeInHierarchy}");
            Debug.Log($"📊 WhisperManager enabled: {whisperManager.enabled}");
        }
        
        if (microphoneRecord != null)
        {
            Debug.Log($"📊 MicrophoneRecord GameObject active: {microphoneRecord.gameObject.activeInHierarchy}");
            Debug.Log($"📊 MicrophoneRecord enabled: {microphoneRecord.enabled}");
        }
    }
    
    [ContextMenu("Auto-Assign Missing Components")]
    public void AutoAssignMissingComponents()
    {
        Debug.Log("🔧 Auto-assigning missing components...");
        
        // Find VoiceCore if missing
        if (voiceCore == null)
        {
            voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
            if (voiceCore != null)
            {
                Debug.Log("🔧 Auto-assigned ARVoiceRecognitionCore");
            }
        }
        
        // Find WhisperManager if missing
        if (whisperManager == null)
        {
            whisperManager = FindFirstObjectByType<WhisperManager>();
            if (whisperManager != null)
            {
                Debug.Log("🔧 Auto-assigned WhisperManager");
            }
        }
        
        // Find MicrophoneRecord if missing
        if (microphoneRecord == null)
        {
            microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
            if (microphoneRecord != null)
            {
                Debug.Log("🔧 Auto-assigned MicrophoneRecord");
            }
        }
        
        // Auto-assign to VoiceCore if found
        if (voiceCore != null)
        {
            if (voiceCore.whisperManager == null && whisperManager != null)
            {
                voiceCore.whisperManager = whisperManager;
                Debug.Log("🔧 Auto-assigned WhisperManager to VoiceCore");
            }
            
            if (voiceCore.microphoneRecord == null && microphoneRecord != null)
            {
                voiceCore.microphoneRecord = microphoneRecord;
                Debug.Log("🔧 Auto-assigned MicrophoneRecord to VoiceCore");
            }
        }
        
        // Re-run diagnostics
        RunDiagnostics();
    }
    
    private void UpdateDiagnosticStatus()
    {
        if (voiceCore == null)
        {
            diagnosticStatus = "VoiceCore Missing";
            return;
        }
        
        if (voiceCore.whisperManager == null || voiceCore.microphoneRecord == null)
        {
            diagnosticStatus = "Missing References";
            return;
        }
        
        if (voiceCore.whisperManager != null && !voiceCore.whisperManager.IsLoaded)
        {
            diagnosticStatus = "WhisperManager Loading";
            return;
        }
        
        if (voiceCore.IsInitialized)
        {
            diagnosticStatus = "All Good - Initialized";
        }
        else
        {
            diagnosticStatus = "Ready - Not Initialized";
        }
    }
    
    [ContextMenu("Fix Common Issues")]
    public void FixCommonIssues()
    {
        Debug.Log("🔧 Attempting to fix common issues...");
        
        // Issue 1: Missing component references
        AutoAssignMissingComponents();
        
        // Issue 2: Disabled GameObjects
        if (voiceCore != null && !voiceCore.gameObject.activeInHierarchy)
        {
            voiceCore.gameObject.SetActive(true);
            Debug.Log("🔧 Enabled VoiceCore GameObject");
        }
        
        if (whisperManager != null && !whisperManager.gameObject.activeInHierarchy)
        {
            whisperManager.gameObject.SetActive(true);
            Debug.Log("🔧 Enabled WhisperManager GameObject");
        }
        
        if (microphoneRecord != null && !microphoneRecord.gameObject.activeInHierarchy)
        {
            microphoneRecord.gameObject.SetActive(true);
            Debug.Log("🔧 Enabled MicrophoneRecord GameObject");
        }
        
        // Issue 3: Force refresh Editor
        #if UNITY_EDITOR
        UnityEditor.EditorUtility.SetDirty(this);
        if (voiceCore != null)
            UnityEditor.EditorUtility.SetDirty(voiceCore);
        #endif
        
        Debug.Log("🔧 Fixed common issues. Check diagnostics again.");
        RunDiagnostics();
    }
}

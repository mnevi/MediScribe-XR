using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using Whisper.Utils;

/// <summary>
/// Clean and robust voice recognition button for controlling ARVoiceRecognitionCore
/// Simplified version with essential functionality only
/// </summary>
public class BulletproofVoiceButton : MonoBehaviour
{
    [Header("Required Components")]
    [Tooltip("The UI Button component - this MUST be assigned")]
    public Button recordButton;
    
    [Header("Text Component - Choose One")]
    [Tooltip("For UI buttons, use TextMeshProUGUI (not TextMeshPro)")]
    public TextMeshProUGUI buttonTextTMP;
    
    [Tooltip("Legacy Unity Text component (if not using TextMeshPro)")]
    public Text buttonText;
    
    [Header("Button States")]
    public string idleText = "Record";
    public string recordingText = "Stop";
    public string processingText = "Processing...";
    public string errorText = "Error";
    
    [Header("Button Colors")]
    public Color idleColor = new Color(0.2f, 0.7f, 0.3f, 1f);      // Green
    public Color recordingColor = new Color(0.8f, 0.2f, 0.2f, 1f);  // Red
    public Color processingColor = new Color(0.8f, 0.6f, 0.2f, 1f); // Orange
    public Color errorColor = new Color(0.5f, 0.5f, 0.5f, 1f);      // Gray
    
    [Header("Core Component - AUTO-FOUND")]
    [Tooltip("ARVoiceRecognitionCore - will be auto-found if not assigned")]
    public ARVoiceRecognitionCore voiceRecognitionCore;
    
    [Header("Microphone Validation")]
    [Tooltip("Reference to MicrophoneRecord component for validation")]
    public MicrophoneRecord microphoneRecord;
    
    [Tooltip("Enable microphone validity checks")]
    public bool enableMicrophoneValidation = true;
    
    [Tooltip("Use strict microphone testing (may fail on some systems)")]
    public bool strictMicrophoneValidation = false;
    
    [Header("Settings")]
    [Tooltip("Enable detailed debug logging")]
    public bool enableDebugLogging = true;
    
    [Tooltip("Maximum time to wait for voice core operations before timing out")]
    public float operationTimeout = 5f;
    
    [Tooltip("Time to wait before allowing another button click after error")]
    public float errorCooldown = 2f;
    
    [Tooltip("Minimum time between button clicks")]
    public float clickCooldown = 0.5f;
    
    // Internal state tracking
    private bool isRecording = false;
    private bool isProcessing = false;
    private bool isInError = false;
    private bool isInitialized = false;
    private bool hasValidComponents = false;
    
    // Component validation flags
    private bool hasButton = false;
    private bool hasTextComponent = false;
    private bool hasVoiceCore = false;
    private bool hasMicrophoneRecord = false;
    private bool hasMicrophoneDevices = false;
    private bool microphonePermissionsGranted = false;
    
    // Timing
    private float lastErrorTime = 0f;
    private float lastClickTime = 0f;
    
    // Coroutines
    private Coroutine recoveryCoroutine;
    
    // State tracking
    private enum ButtonState
    {
        Idle,
        Recording,
        Processing,
        Error
    }
    
    void Start()
    {
        if (isInitialized)
        {
            LogDebug("Already initialized, skipping Start()");
            return;
        }
        
        StartCoroutine(SafeInitialization());
    }
    
    IEnumerator SafeInitialization()
    {
        yield return new WaitForEndOfFrame();
        
        LogDebug("Starting safe initialization...");
        
        ValidateAllComponents();
        
        if (hasValidComponents)
        {
            SetupButton();
            ConnectToVoiceRecognition();
            
            // Validate microphone asynchronously if enabled
            if (enableMicrophoneValidation)
            {
                StartCoroutine(ValidateMicrophoneHardware());
            }
            
            SetButtonState(ButtonState.Idle);
            isInitialized = true;
            LogDebug("Initialization completed successfully");
        }
        else
        {
            LogError("Initialization failed - missing required components");
            SetButtonState(ButtonState.Error);
            
            // Try to recover
            StartCoroutine(RecoveryAttempt());
        }
    }
    
    void ValidateAllComponents()
    {
        LogDebug("Validating all components...");
        
        // Reset validation flags
        hasButton = false;
        hasTextComponent = false;
        hasVoiceCore = false;
        hasMicrophoneRecord = false;
        hasMicrophoneDevices = false;
        
        // Validate button
        hasButton = (recordButton != null);
        if (!hasButton)
        {
            LogError("Record button is not assigned!");
            return;
        }
        LogDebug("✅ Button validated");
        
        // Validate text component
        hasTextComponent = (buttonTextTMP != null || buttonText != null);
        if (!hasTextComponent)
        {
            LogError("No text component assigned (need either TextMeshProUGUI or Text)!");
        }
        else
        {
            LogDebug("✅ Text component validated");
        }
        
        // Find voice recognition core
        if (voiceRecognitionCore == null)
        {
            voiceRecognitionCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
        }
        
        hasVoiceCore = (voiceRecognitionCore != null);
        if (!hasVoiceCore)
        {
            LogError("ARVoiceRecognitionCore not found in scene!");
        }
        else
        {
            LogDebug("✅ Voice recognition core found");
        }
        
        // Find microphone record component
        if (microphoneRecord == null && voiceRecognitionCore != null)
        {
            microphoneRecord = voiceRecognitionCore.microphoneRecord;
        }
        
        if (microphoneRecord == null)
        {
            microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
        }
        
        hasMicrophoneRecord = (microphoneRecord != null);
        if (!hasMicrophoneRecord)
        {
            LogError("MicrophoneRecord component not found!");
        }
        else
        {
            LogDebug("✅ Microphone record component found");
        }
        
        // Basic microphone device check
        try
        {
            string[] devices = Microphone.devices;
            hasMicrophoneDevices = (devices != null && devices.Length > 0);
            
            if (hasMicrophoneDevices)
            {
                LogDebug($"✅ Found {devices.Length} microphone device(s)");
            }
            else
            {
                LogError("No microphone devices detected!");
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error checking microphone devices: {e.Message}");
            hasMicrophoneDevices = false;
        }
        
        // Overall validation
        if (enableMicrophoneValidation)
        {
            hasValidComponents = hasButton && hasVoiceCore && hasMicrophoneRecord && hasMicrophoneDevices;
        }
        else
        {
            hasValidComponents = hasButton && hasVoiceCore;
            LogDebug("⚠️ Microphone validation disabled - skipping microphone checks");
        }
        
        LogDebug($"Component validation complete - Valid: {hasValidComponents}");
    }
    
    IEnumerator ValidateMicrophoneHardware()
    {
        LogDebug("Starting microphone hardware validation...");
        
        if (!strictMicrophoneValidation)
        {
            LogDebug("Using basic microphone validation (non-strict mode)");
            // Just check if devices exist and assume permissions are OK
            microphonePermissionsGranted = hasMicrophoneDevices;
            
            if (microphonePermissionsGranted)
            {
                LogDebug("✅ Basic microphone validation passed");
            }
            else
            {
                LogError("Basic microphone validation failed - no devices found");
            }
        }
        else
        {
            LogDebug("Using strict microphone validation");
            yield return StartCoroutine(TestMicrophonePermissions());
        }
        
        // Update overall validation status
        hasValidComponents = hasButton && hasVoiceCore && hasMicrophoneRecord && 
                           hasMicrophoneDevices && microphonePermissionsGranted;
        
        if (!microphonePermissionsGranted)
        {
            LogError("Microphone validation failed");
            if (strictMicrophoneValidation)
            {
                HandleOperationError("Microphone validation failed");
            }
            else
            {
                LogDebug("⚠️ Microphone validation failed but continuing (non-strict mode)");
                // In non-strict mode, continue anyway
                hasValidComponents = hasButton && hasVoiceCore && hasMicrophoneRecord && hasMicrophoneDevices;
            }
        }
        else
        {
            LogDebug("✅ Microphone validation passed");
        }
    }
    
    IEnumerator TestMicrophonePermissions()
    {
        LogDebug("Testing microphone permissions...");
        
        AudioClip testClip = null;
        string deviceToTest = null;
        bool permissionTestStarted = false;
        
        try
        {
            string[] devices = Microphone.devices;
            if (devices != null && devices.Length > 0)
            {
                deviceToTest = string.IsNullOrEmpty(devices[0]) ? null : devices[0];
                LogDebug($"Testing device: {deviceToTest ?? "[Default]"}");
            }
            else
            {
                LogError("No microphone devices available for testing");
                microphonePermissionsGranted = false;
                yield break;
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error getting microphone devices: {e.Message}");
            microphonePermissionsGranted = false;
            yield break;
        }
        
        // Try to start microphone recording
        try
        {
            testClip = Microphone.Start(deviceToTest, false, 1, 44100);
            permissionTestStarted = (testClip != null);
            
            if (permissionTestStarted)
            {
                LogDebug("Microphone test recording started");
            }
            else
            {
                LogError("Failed to start microphone test recording");
            }
        }
        catch (System.Exception e)
        {
            LogError($"Exception starting microphone test: {e.Message}");
            permissionTestStarted = false;
        }
        
        if (!permissionTestStarted)
        {
            LogError("Microphone permission denied or device unavailable");
            microphonePermissionsGranted = false;
            yield break;
        }
        
        // Wait and check if recording is working (with multiple attempts)
        yield return new WaitForSeconds(0.1f);
        
        bool isRecordingActive = false;
        int maxAttempts = 5;
        
        for (int attempt = 0; attempt < maxAttempts; attempt++)
        {
            try
            {
                isRecordingActive = Microphone.IsRecording(deviceToTest);
                
                if (isRecordingActive)
                {
                    LogDebug($"✅ Microphone recording confirmed on attempt {attempt + 1}");
                    break;
                }
                else
                {
                    LogDebug($"Microphone not recording yet, attempt {attempt + 1}/{maxAttempts}");
                }
            }
            catch (System.Exception e)
            {
                LogError($"Error checking microphone recording on attempt {attempt + 1}: {e.Message}");
            }
            
            // Wait before next attempt (outside try-catch)
            if (attempt < maxAttempts - 1)
            {
                yield return new WaitForSeconds(0.2f);
            }
        }
        
        if (isRecordingActive)
        {
            microphonePermissionsGranted = true;
            LogDebug("✅ Microphone permissions confirmed");
        }
        else
        {
            LogDebug("⚠️ Microphone test inconclusive, but will assume permissions are granted");
            // Don't fail the validation - the microphone might still work for the actual voice recognition
            microphonePermissionsGranted = true;
        }
        
        // Clean up
        try
        {
            if (Microphone.IsRecording(deviceToTest))
            {
                Microphone.End(deviceToTest);
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error stopping microphone test: {e.Message}");
        }
    }
    
    void SetupButton()
    {
        if (!hasButton) return;
        
        try
        {
            recordButton.onClick.RemoveAllListeners();
            recordButton.onClick.AddListener(OnButtonClick);
            LogDebug("Button setup complete");
        }
        catch (System.Exception e)
        {
            LogError($"Error setting up button: {e.Message}");
        }
    }
    
    void ConnectToVoiceRecognition()
    {
        if (!hasVoiceCore) return;
        
        try
        {
            if (voiceRecognitionCore.OnRecordingStateChanged != null)
            {
                voiceRecognitionCore.OnRecordingStateChanged.AddListener(OnRecordingStateChanged);
            }
            
            if (voiceRecognitionCore.OnStatusChanged != null)
            {
                voiceRecognitionCore.OnStatusChanged.AddListener(OnStatusChanged);
            }
            
            if (voiceRecognitionCore.OnErrorOccurred != null)
            {
                voiceRecognitionCore.OnErrorOccurred.AddListener(OnVoiceRecognitionError);
            }
            
            LogDebug("Voice recognition events connected");
        }
        catch (System.Exception e)
        {
            LogError($"Error connecting to voice recognition: {e.Message}");
        }
    }
    
    void OnButtonClick()
    {
        float currentTime = Time.time;
        LogDebug($"🔘 BUTTON CLICKED! Current state - Recording: {isRecording}, Processing: {isProcessing}");
        LogDebug($"🔘 Click source: {System.Environment.StackTrace.Split('\n')[1]}"); // Show what called this
        
        // Check for rapid clicks
        if (currentTime - lastClickTime < clickCooldown)
        {
            LogDebug($"Rapid click detected, ignoring (time since last: {currentTime - lastClickTime:F3}s)");
            return;
        }
        lastClickTime = currentTime;
        
        // Check if can process click
        if (!CanProcessClick())
        {
            LogDebug("🔘 CanProcessClick returned false - click ignored");
            return;
        }
        
        LogDebug("🔘 Click accepted - starting voice toggle");
        
        // Handle voice toggle
        StartCoroutine(HandleVoiceToggle());
    }
    
    bool CanProcessClick()
    {
        // Check initialization
        if (!isInitialized)
        {
            LogError("Button not initialized");
            return false;
        }
        
        // Check if in error state
        if (isInError && Time.time - lastErrorTime < errorCooldown)
        {
            LogDebug("Still in error recovery period");
            return false;
        }
        
        // Check if already processing
        if (isProcessing)
        {
            LogDebug("Already processing, ignoring click");
            return false;
        }
        
        // Check component validity
        if (!ComponentsStillValid())
        {
            LogError("Components no longer valid");
            HandleOperationError("Components became invalid");
            return false;
        }
        
        return true;
    }
    
    bool ComponentsStillValid()
    {
        try
        {
            if (voiceRecognitionCore == null || !voiceRecognitionCore.enabled || 
                !voiceRecognitionCore.gameObject.activeInHierarchy)
            {
                return false;
            }
            
            if (enableMicrophoneValidation)
            {
                if (microphoneRecord == null || !microphoneRecord.enabled || 
                    !microphoneRecord.gameObject.activeInHierarchy)
                {
                    return false;
                }
            }
            
            return true;
        }
        catch (System.Exception e)
        {
            LogError($"Error checking component validity: {e.Message}");
            return false;
        }
    }
    
    IEnumerator HandleVoiceToggle()
    {
        isProcessing = true;
        SetButtonState(ButtonState.Processing);
        
        bool success = false;
        bool wasRecording = isRecording;
        bool expectedState = !wasRecording; // What we expect after toggling
        
        try
        {
            LogDebug($"Toggling voice recognition (currently recording: {isRecording}, expecting: {expectedState})");
            
            // Call the voice recognition toggle
            voiceRecognitionCore.ToggleVoiceRecognition();
            success = true;
        }
        catch (System.Exception e)
        {
            LogError($"Voice toggle failed: {e.Message}");
            HandleOperationError("Voice toggle failed");
        }
        
        if (success)
        {
            // Wait for the voice core to complete the toggle operation
            // The OnRecordingStateChanged event will update our isRecording state
            yield return new WaitForSeconds(0.3f);
            
            // Check if we got the expected result or if voice core overrode our request
            if (isRecording == expectedState)
            {
                LogDebug($"Voice toggle successful - Now recording: {isRecording}");
            }
            else if (wasRecording && !expectedState && isRecording)
            {
                LogDebug("Voice core extended recording (likely due to minimum duration requirement)");
            }
            else
            {
                LogDebug($"Voice toggle resulted in unexpected state - Expected: {expectedState}, Actual: {isRecording}");
            }
            
            // Set button state based on current recording state
            SetButtonState(isRecording ? ButtonState.Recording : ButtonState.Idle);
            isInError = false;
        }
        
        isProcessing = false;
    }
    
    void HandleOperationError(string errorMessage)
    {
        isInError = true;
        lastErrorTime = Time.time;
        
        SetButtonState(ButtonState.Error);
        LogError($"Operation error: {errorMessage}");
        
        // Try to recover after a delay
        if (recoveryCoroutine != null)
        {
            StopCoroutine(recoveryCoroutine);
        }
        recoveryCoroutine = StartCoroutine(RecoveryAttempt());
    }
    
    IEnumerator RecoveryAttempt()
    {
        yield return new WaitForSeconds(errorCooldown);
        
        LogDebug("Attempting recovery...");
        
        bool recoverySucceeded = false;
        
        try
        {
            ValidateAllComponents();
            
            if (hasValidComponents)
            {
                isInError = false;
                SetButtonState(ButtonState.Idle);
                LogDebug("Recovery successful");
                recoverySucceeded = true;
            }
            else
            {
                LogError("Recovery failed - components still invalid");
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error during recovery: {e.Message}");
        }
        
        if (!recoverySucceeded)
        {
            // Try again later
            yield return new WaitForSeconds(5f);
            StartCoroutine(RecoveryAttempt());
        }
    }
    
    void SetButtonState(ButtonState state)
    {
        try
        {
            if (!hasButton || !gameObject.activeInHierarchy) return;
            
            string text;
            Color color;
            bool interactable = true;
            
            switch (state)
            {
                case ButtonState.Recording:
                    text = recordingText;
                    color = recordingColor;
                    break;
                case ButtonState.Processing:
                    text = processingText;
                    color = processingColor;
                    interactable = false;
                    break;
                case ButtonState.Error:
                    text = errorText;
                    color = errorColor;
                    interactable = false;
                    break;
                default: // Idle
                    text = idleText;
                    color = idleColor;
                    break;
            }
            
            // Update button text
            if (hasTextComponent)
            {
                UpdateButtonText(text);
            }
            
            // Update button interactability
            if (recordButton != null)
            {
                recordButton.interactable = interactable;
            }
            
            // Update button color
            UpdateButtonColor(color);
            
            LogDebug($"Button state set to {state}");
        }
        catch (System.Exception e)
        {
            LogError($"Error setting button state: {e.Message}");
        }
    }
    
    void UpdateButtonText(string text)
    {
        try
        {
            if (buttonTextTMP != null && buttonTextTMP.gameObject.activeInHierarchy)
            {
                buttonTextTMP.text = text;
            }
            else if (buttonText != null && buttonText.gameObject.activeInHierarchy)
            {
                buttonText.text = text;
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error updating button text: {e.Message}");
        }
    }
    
    void UpdateButtonColor(Color color)
    {
        try
        {
            if (recordButton == null || !recordButton.gameObject.activeInHierarchy) return;
            
            ColorBlock colors = recordButton.colors;
            colors.normalColor = color;
            colors.highlightedColor = Color.Lerp(color, Color.white, 0.2f);
            colors.pressedColor = Color.Lerp(color, Color.black, 0.2f);
            colors.disabledColor = Color.Lerp(color, Color.gray, 0.5f);
            
            recordButton.colors = colors;
        }
        catch (System.Exception e)
        {
            LogError($"Error updating button color: {e.Message}");
        }
    }
    
    // Event handlers
    void OnRecordingStateChanged(bool recording)
    {
        try
        {
            if (!isInitialized) return;
            
            LogDebug($"Recording state changed: {recording} (was processing: {isProcessing})");
            
            // Always update our internal state to match the voice core
            isRecording = recording;
            
            // Only update button visual state if we're not currently processing a user-initiated toggle
            // The HandleVoiceToggle coroutine will handle the visual state when it completes
            if (!isProcessing)
            {
                SetButtonState(recording ? ButtonState.Recording : ButtonState.Idle);
            }
            else
            {
                LogDebug("Currently processing user toggle - will update button state when toggle completes");
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error handling recording state change: {e.Message}");
        }
    }
    
    void OnStatusChanged(string status)
    {
        try
        {
            if (!isInitialized || string.IsNullOrEmpty(status)) return;
            
            LogDebug($"Status changed: {status}");
            
            bool wasProcessing = isProcessing;
            isProcessing = status.Contains("Processing") || status.Contains("Loading") || status.Contains("Creating");
            
            // Handle special cases - recording extended due to minimum duration
            if (status.Contains("Recording too short") || (status.Contains("waiting") && status.Contains("more")))
            {
                LogDebug("Recording was too short, system extending recording for minimum duration");
                // The voice core has decided to continue recording despite stop attempt
                // Override our expected state since the voice core is still recording
                isRecording = true;
                SetButtonState(ButtonState.Recording);
                return;
            }
            
            // Only update button state if we're not in the middle of a toggle operation
            // or if processing state changed significantly
            if (!isProcessing || wasProcessing != isProcessing)
            {
                // Update button state if processing state changed and we're not recording
                if (wasProcessing != isProcessing && !isRecording)
                {
                    SetButtonState(isProcessing ? ButtonState.Processing : ButtonState.Idle);
                }
            }
        }
        catch (System.Exception e)
        {
            LogError($"Error handling status change: {e.Message}");
        }
    }
    
    void OnVoiceRecognitionError(string error)
    {
        try
        {
            if (!isInitialized) return;
            
            LogError($"Voice recognition error: {error}");
            HandleOperationError($"Voice core error: {error}");
        }
        catch (System.Exception e)
        {
            LogError($"Error handling voice recognition error: {e.Message}");
        }
    }
    
    // Public interface
    public void ManualReset()
    {
        LogDebug("Manual reset requested");
        
        try
        {
            // Stop all ongoing operations
            if (recoveryCoroutine != null)
            {
                StopCoroutine(recoveryCoroutine);
                recoveryCoroutine = null;
            }
            
            // Reset states
            isRecording = false;
            isProcessing = false;
            isInError = false;
            
            // Reinitialize
            StartCoroutine(SafeInitialization());
        }
        catch (System.Exception e)
        {
            LogError($"Error during manual reset: {e.Message}");
        }
    }
    
    public void ManualMicrophoneValidation()
    {
        LogDebug("Manual microphone validation requested");
        
        if (enableMicrophoneValidation)
        {
            StartCoroutine(ValidateMicrophoneHardware());
        }
        else
        {
            LogDebug("Microphone validation is disabled");
        }
    }
    
    // Status properties
    public bool IsRecording => isRecording;
    public bool IsProcessing => isProcessing;
    public bool IsInitialized => isInitialized;
    public bool HasValidComponents => hasValidComponents;
    public bool IsInError => isInError;
    public bool HasMicrophoneRecord => hasMicrophoneRecord;
    public bool HasMicrophoneDevices => hasMicrophoneDevices;
    public bool MicrophonePermissionsGranted => microphonePermissionsGranted;
    
    // Logging
    void LogDebug(string message)
    {
        if (enableDebugLogging)
        {
            Debug.Log($"[BulletproofVoice] {message}");
        }
    }
    
    void LogError(string message)
    {
        Debug.LogError($"[BulletproofVoice] {message}");
    }
    
    // Unity lifecycle
    void OnDestroy()
    {
        if (recoveryCoroutine != null)
        {
            StopCoroutine(recoveryCoroutine);
        }
    }
    
    #if UNITY_EDITOR
    [ContextMenu("Debug - Manual Reset")]
    void DebugManualReset()
    {
        ManualReset();
    }
    
    [ContextMenu("Debug - Show Current State")]
    void DebugShowCurrentState()
    {
        Debug.Log("=== BULLETPROOF VOICE BUTTON STATE ===");
        Debug.Log($"📍 Initialized: {isInitialized}");
        Debug.Log($"🎙️ Recording: {isRecording}");
        Debug.Log($"⚙️ Processing: {isProcessing}");
        Debug.Log($"❌ In Error: {isInError}");
        Debug.Log($"✅ Valid Components: {hasValidComponents}");
        Debug.Log($"🔘 Has Button: {hasButton}");
        Debug.Log($"📝 Has Text: {hasTextComponent}");
        Debug.Log($"🗣️ Has Voice Core: {hasVoiceCore}");
        Debug.Log($"🎙️ Has Microphone: {hasMicrophoneRecord}");
        Debug.Log($"📱 Has Devices: {hasMicrophoneDevices}");
        Debug.Log($"🔐 Mic Permissions: {microphonePermissionsGranted}");
        Debug.Log($"🔧 Mic Validation Enabled: {enableMicrophoneValidation}");
        Debug.Log($"⚡ Strict Mic Validation: {strictMicrophoneValidation}");
    }
    
    [ContextMenu("Debug - Test Component Check")]
    void DebugTestComponentCheck()
    {
        Debug.Log("=== TESTING COMPONENT CHECK ===");
        bool checkResult = ComponentsStillValid();
        Debug.Log($"Component Check Result: {(checkResult ? "PASSED ✅" : "FAILED ❌")}");
    }
    
    [ContextMenu("Debug - Force Sync With Voice Core")]
    void DebugForceSyncWithVoiceCore()
    {
        if (voiceRecognitionCore != null)
        {
            bool voiceCoreRecording = voiceRecognitionCore.IsRecording;
            Debug.Log($"=== FORCE SYNC WITH VOICE CORE ===");
            Debug.Log($"Button thinks recording: {isRecording}");
            Debug.Log($"Voice core actually recording: {voiceCoreRecording}");
            
            if (isRecording != voiceCoreRecording)
            {
                Debug.Log($"🔄 Syncing button state to match voice core");
                isRecording = voiceCoreRecording;
                SetButtonState(isRecording ? ButtonState.Recording : ButtonState.Idle);
            }
            else
            {
                Debug.Log($"✅ Button and voice core are already in sync");
            }
        }
        else
        {
            Debug.LogError("Voice core not found!");
        }
    }
    
    [ContextMenu("Debug - Show Voice Core State")]
    void DebugShowVoiceCoreState()
    {
        if (voiceRecognitionCore != null)
        {
            Debug.Log("=== VOICE CORE STATE ===");
            Debug.Log($"🎙️ Voice Core Recording: {voiceRecognitionCore.IsRecording}");
            Debug.Log($"🔘 Button Recording: {isRecording}");
            Debug.Log($"⚙️ Button Processing: {isProcessing}");
            Debug.Log($"📊 States Match: {(isRecording == voiceRecognitionCore.IsRecording ? "YES ✅" : "NO ❌")}");
        }
        else
        {
            Debug.LogError("Voice core not found!");
        }
    }
    
    [ContextMenu("Debug - Test Voice Toggle")]
    void DebugTestVoiceToggle()
    {
        if (!isInitialized)
        {
            Debug.LogError("Button not initialized!");
            return;
        }
        
        if (isProcessing)
        {
            Debug.LogError("Already processing a toggle!");
            return;
        }
        
        Debug.Log("=== TESTING VOICE TOGGLE ===");
        Debug.Log($"Current state before toggle: Recording={isRecording}");
        OnButtonClick();
    }
    
    [ContextMenu("Debug - Direct Voice Core Toggle")]
    void DebugDirectVoiceCoreToggle()
    {
        if (voiceRecognitionCore == null)
        {
            Debug.LogError("Voice core not found!");
            return;
        }
        
        Debug.Log("=== DIRECT VOICE CORE TOGGLE ===");
        Debug.Log($"Voice core recording before: {voiceRecognitionCore.IsRecording}");
        Debug.Log($"Button recording before: {isRecording}");
        
        try
        {
            voiceRecognitionCore.ToggleVoiceRecognition();
            Debug.Log("✅ Direct toggle called successfully");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Direct toggle failed: {e.Message}");
        }
    }
    
    [ContextMenu("Debug - Start Recording Only")]
    void DebugStartRecording()
    {
        if (voiceRecognitionCore == null)
        {
            Debug.LogError("Voice core not found!");
            return;
        }
        
        Debug.Log("=== START RECORDING ===");
        Debug.Log($"Current recording state: {voiceRecognitionCore.IsRecording}");
        
        if (!voiceRecognitionCore.IsRecording)
        {
            try
            {
                voiceRecognitionCore.ToggleVoiceRecognition(); // Will start if not recording
                Debug.Log("✅ Toggle called to start recording");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ Start recording failed: {e.Message}");
            }
        }
        else
        {
            Debug.Log("⚠️ Already recording!");
        }
    }
    
    [ContextMenu("Debug - Stop Recording Only")]
    void DebugStopRecording()
    {
        if (voiceRecognitionCore == null)
        {
            Debug.LogError("Voice core not found!");
            return;
        }
        
        Debug.Log("=== STOP RECORDING ===");
        Debug.Log($"Current recording state: {voiceRecognitionCore.IsRecording}");
        
        if (voiceRecognitionCore.IsRecording)
        {
            try
            {
                voiceRecognitionCore.ToggleVoiceRecognition(); // Will stop if recording
                Debug.Log("✅ Toggle called to stop recording");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ Stop recording failed: {e.Message}");
            }
        }
        else
        {
            Debug.Log("⚠️ Not currently recording!");
        }
    }
    
    [ContextMenu("Debug - Test Button Click Event")]
    void DebugTestButtonClickEvent()
    {
        Debug.Log("=== TESTING BUTTON CLICK EVENT ===");
        Debug.Log($"Button assigned: {recordButton != null}");
        
        if (recordButton != null)
        {
            Debug.Log($"Button active: {recordButton.gameObject.activeInHierarchy}");
            Debug.Log($"Button enabled: {recordButton.enabled}");
            Debug.Log($"Button interactable: {recordButton.interactable}");
            Debug.Log($"Button listener count: {recordButton.onClick.GetPersistentEventCount()}");
            
            // Manually trigger the button's onClick event
            Debug.Log("🔘 Manually triggering button onClick event...");
            recordButton.onClick.Invoke();
        }
        else
        {
            Debug.LogError("❌ Record button is null!");
        }
    }
    
    [ContextMenu("Debug - Simulate UI Button Press")]
    void DebugSimulateUIButtonPress()
    {
        Debug.Log("=== SIMULATING UI BUTTON PRESS ===");
        Debug.Log("This simulates exactly what should happen when the UI button is pressed");
        Debug.Log($"Before press - Recording: {isRecording}, Processing: {isProcessing}");
        
        // This directly calls our OnButtonClick method, simulating a UI button press
        OnButtonClick();
        
        Debug.Log("✅ UI button press simulation completed");
    }
    
    [ContextMenu("Debug - Check Button Setup")]
    void DebugCheckButtonSetup()
    {
        Debug.Log("=== CHECKING BUTTON SETUP ===");
        
        if (recordButton == null)
        {
            Debug.LogError("❌ Record button is null!");
            return;
        }
        
        Debug.Log($"✅ Button exists: {recordButton.name}");
        Debug.Log($"✅ Button active in hierarchy: {recordButton.gameObject.activeInHierarchy}");
        Debug.Log($"✅ Button component enabled: {recordButton.enabled}");
        Debug.Log($"✅ Button interactable: {recordButton.interactable}");
        Debug.Log($"✅ Button raycast target: {recordButton.targetGraphic != null && recordButton.targetGraphic.raycastTarget}");
        
        // Check for event listeners
        var onClick = recordButton.onClick;
        int persistentCount = onClick.GetPersistentEventCount();
        Debug.Log($"📊 Persistent listeners: {persistentCount}");
        
        // Try to get runtime listener count (this is tricky but we can try)
        var field = typeof(UnityEngine.Events.UnityEventBase).GetField("m_Calls", 
            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        if (field != null)
        {
            var calls = field.GetValue(onClick);
            if (calls != null)
            {
                var runtimeField = calls.GetType().GetField("m_RuntimeCalls", 
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                if (runtimeField != null)
                {
                    var runtimeCalls = runtimeField.GetValue(calls) as System.Collections.IList;
                    Debug.Log($"📊 Runtime listeners: {runtimeCalls?.Count ?? 0}");
                }
            }
        }
        
        // Check if our method is actually connected
        Debug.Log("🔍 Testing if our OnButtonClick method is connected...");
        bool hasOurListener = false;
        
        for (int i = 0; i < persistentCount; i++)
        {
            var target = onClick.GetPersistentTarget(i);
            var methodName = onClick.GetPersistentMethodName(i);
            
            if (target == this && methodName == "OnButtonClick")
            {
                hasOurListener = true;
                Debug.Log($"✅ Found our listener at index {i}");
                break;
            }
        }
        
        if (!hasOurListener)
        {
            Debug.LogError("❌ Our OnButtonClick method is not connected to the button!");
            Debug.Log("🔧 Attempting to reconnect...");
            SetupButton();
        }
        else
        {
            Debug.Log("✅ Our OnButtonClick method is properly connected");
        }
    }
    #endif
}
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using Whisper.Utils;
using Whisper;

/// <summary>
/// Core AR voice recognition functionality without UI creation
/// Pure logic component that fires events for UI integration
/// 
/// IMPORTANT: WhisperStream stops automatically when microphone stops.
/// Do not attempt to manually stop WhisperStream - it handles cleanup internally.
/// Only control the MicrophoneRecord component for start/stop operations.
/// </summary>
public class ARVoiceRecognitionCore : MonoBehaviour
{
    [Header("Voice Recognition Components (Assign in Inspector)")]
    [Tooltip("WhisperManager component - drag from scene")]
    public WhisperManager whisperManager;
    
    [Tooltip("MicrophoneRecord component - drag from scene")]
    public MicrophoneRecord microphoneRecord;
    
    [Header("Optional UI Integration (Leave empty to use events only)")]
    [Tooltip("Optional status text component for direct UI updates")]
    public UnityEngine.UI.Text statusText;
    
    [Tooltip("Auto-hide UI panel after transcription")]
    public bool autoHide = true;
    
    [Header("Real-time Configuration")]
    [Tooltip("Show partial transcription results in real-time")]
    public bool enableRealTimeDisplay = true;
    
    [Tooltip("Minimum confidence threshold for displaying partial results")]
    [Range(0f, 1f)]
    public float confidenceThreshold = 0.3f;
    
    [Tooltip("Update frequency for real-time display (seconds)")]
    [Range(0.1f, 2f)]
    public float updateFrequency = 0.5f;
    
    // Core functionality
    private WhisperStream whisperStream;
    private bool isListening = false;
    private bool isInitialized = false;
    private string lastTranscription = "";
    private string currentStatus = "Not initialized";
    private float recordingStartTime = 0f;
    private const float MINIMUM_RECORDING_DURATION = 0.5f; // Minimum 0.5 seconds
    
    // Events for UI integration
    public UnityEngine.Events.UnityEvent<string> OnTranscriptionReceived;
    public UnityEngine.Events.UnityEvent<string> OnStatusChanged;
    public UnityEngine.Events.UnityEvent<string> OnErrorOccurred;
    public UnityEngine.Events.UnityEvent<bool> OnRecordingStateChanged;
    
    private void Start()
    {
        ValidateComponents();
        
        if (AreComponentsValid())
        {
            StartCoroutine(InitializeVoiceRecognition());
        }
    }
    
    private void ValidateComponents()
    {
        bool allValid = true;
        
        if (whisperManager == null)
        {
            Debug.LogError("ARVoiceRecognitionCore: WhisperManager not assigned! Please drag a WhisperManager component from your scene.");
            OnErrorOccurred?.Invoke("WhisperManager not assigned");
            allValid = false;
            
            // Try to auto-find in scene
            whisperManager = FindFirstObjectByType<WhisperManager>();
            if (whisperManager != null)
            {
                Debug.Log("🔧 Auto-found WhisperManager in scene");
                allValid = true;
            }
        }
        
        if (microphoneRecord == null)
        {
            Debug.LogError("ARVoiceRecognitionCore: MicrophoneRecord not assigned! Please drag a MicrophoneRecord component from your scene.");
            OnErrorOccurred?.Invoke("MicrophoneRecord not assigned");
            allValid = false;
            
            // Try to auto-find in scene
            microphoneRecord = FindFirstObjectByType<MicrophoneRecord>();
            if (microphoneRecord != null)
            {
                Debug.Log("🔧 Auto-found MicrophoneRecord in scene");
                allValid = true;
            }
        }
        
        if (!allValid)
        {
            SetStatus("Missing Components - Check Console");
        }
        else
        {
            Debug.Log("✅ All components validated successfully");
        }
    }
    
    private bool AreComponentsValid()
    {
        return whisperManager != null && microphoneRecord != null;
    }
    
    private void SetStatus(string status)
    {
        currentStatus = status;
        
        // Fire event for external UI
        OnStatusChanged?.Invoke(status);
        
        // Optional direct UI update
        if (statusText != null)
        {
            statusText.text = status;
        }
        
        Debug.Log($"ARVoiceRecognitionCore Status: {status}");
    }
    
    private System.Collections.IEnumerator InitializeVoiceRecognition()
    {
        if (!AreComponentsValid())
        {
            SetStatus("Error: Missing components");
            yield break;
        }
        
        SetStatus("Initializing...");
        
        // Wait for WhisperManager to load
        float timeout = 30f; // 30 second timeout
        
        Debug.Log($"🔍 [TIMER DEBUG] Starting initialization loop. IsLoaded: {whisperManager.IsLoaded}");
        
        // Use a robust timer approach for better Editor/Device compatibility
        float startTime = Time.realtimeSinceStartup;
        
        while (!whisperManager.IsLoaded && (Time.realtimeSinceStartup - startTime) < timeout)
        {
            float elapsedTime = Time.realtimeSinceStartup - startTime;
            SetStatus($"Loading model... {elapsedTime:F1}s");
            Debug.Log($"🔍 [TIMER DEBUG] Timer at {elapsedTime:F1}s, IsLoaded: {whisperManager.IsLoaded}");
            
            // Multiple yield strategies for better Editor compatibility
            yield return new WaitForSecondsRealtime(0.1f);
            yield return null; // Wait one frame
        }
        
        float finalElapsed = Time.realtimeSinceStartup - startTime;
        Debug.Log($"🔍 [TIMER DEBUG] Loop ended. Time: {finalElapsed:F1}s, IsLoaded: {whisperManager.IsLoaded}");
        
        if (!whisperManager.IsLoaded)
        {
            SetStatus("Error: Model failed to load");
            OnErrorOccurred?.Invoke("WhisperManager failed to load within timeout period. Check model path and configuration.");
            yield break;
        }
        
        // Create WhisperStream for continuous recognition
        yield return StartCoroutine(CreateWhisperStreamCoroutine());
    }
    
    private System.Collections.IEnumerator CreateWhisperStreamCoroutine()
    {
        SetStatus("Creating stream...");
        
        Debug.Log("🔍 [TIMER DEBUG] Starting stream creation...");
        
        // Use a task-based approach that's compatible with coroutines
        var createStreamTask = whisperManager.CreateStream(microphoneRecord);
        
        // Wait for the task to complete with timeout
        float timeout = 10f;
        float startTime = Time.realtimeSinceStartup;
        
        Debug.Log($"🔍 [TIMER DEBUG] Stream creation loop starting. IsCompleted: {createStreamTask.IsCompleted}");
        
        while (!createStreamTask.IsCompleted && (Time.realtimeSinceStartup - startTime) < timeout)
        {
            float elapsedTime = Time.realtimeSinceStartup - startTime;
            SetStatus($"Creating stream... {elapsedTime:F1}s");
            Debug.Log($"🔍 [TIMER DEBUG] Stream timer at {elapsedTime:F1}s, IsCompleted: {createStreamTask.IsCompleted}");
            
            // Use multiple yield strategies for better Editor compatibility
            yield return new WaitForSecondsRealtime(0.1f);
            yield return null; // Wait one frame
        }
        
        float finalElapsed = Time.realtimeSinceStartup - startTime;
        Debug.Log($"🔍 [TIMER DEBUG] Stream loop ended. Time: {finalElapsed:F1}s, IsCompleted: {createStreamTask.IsCompleted}");
        
        if (!createStreamTask.IsCompleted || (Time.realtimeSinceStartup - startTime) >= timeout)
        {
            SetStatus("Error: Stream timeout");
            OnErrorOccurred?.Invoke("WhisperStream creation timed out");
            yield break;
        }
        
        try
        {
            whisperStream = createStreamTask.Result;
            if (whisperStream != null)
            {
                whisperStream.OnResultUpdated += OnTranscriptionUpdated;
                whisperStream.OnStreamFinished += OnTranscriptionFinished;
                isInitialized = true;
                SetStatus("Ready");
                Debug.Log("✅ AR Voice Recognition fully initialized!");
            }
            else
            {
                SetStatus("Error: Stream null");
                OnErrorOccurred?.Invoke("WhisperStream creation returned null");
            }
        }
        catch (System.Exception e)
        {
            SetStatus("Error: Stream failed");
            OnErrorOccurred?.Invoke($"WhisperStream creation failed: {e.Message}");
            
            // Provide helpful debugging information
            Debug.LogError("Troubleshooting tips:");
            Debug.LogError("1. Check if WhisperManager model path is correct");
            Debug.LogError("2. Ensure model file exists in StreamingAssets");
            Debug.LogError("3. Verify WhisperManager is fully loaded");
            Debug.LogError("4. Check microphone permissions");
        }
    }
    
    // function linked to record button
    public void ToggleVoiceRecognition()
    {
        if (!isInitialized)
        {
            SetStatus("Not ready");
            Debug.LogWarning("Voice recognition not initialized yet!");
            return;
        }

        if (!isListening)
        {
            StartListening();
        }
        else
        {
            StopListening();
        }
    }
    
    private void StartListening()
    {
        if (!isInitialized || isListening || whisperStream == null) 
        {
            Debug.LogWarning("Cannot start listening - conditions not met");
            return;
        }
        
        try
        {
            Debug.Log("🎤 Starting voice recognition...");
            
            // Validate components before starting
            if (whisperStream == null)
            {
                OnErrorOccurred?.Invoke("WhisperStream is null - system not properly initialized");
                return;
            }
            
            if (microphoneRecord == null)
            {
                OnErrorOccurred?.Invoke("MicrophoneRecord is null - component not assigned");
                return;
            }
            
            // Check if microphone is already recording
            if (microphoneRecord.IsRecording)
            {
                Debug.LogWarning("⚠️ MicrophoneRecord is already recording, stopping first...");
                microphoneRecord.StopRecord();
                // Brief pause handled by next frame update
            }
            
            // Start the whisper stream first
            whisperStream.StartStream();
            Debug.Log("✅ WhisperStream started");
            
            // Then start microphone recording
            microphoneRecord.StartRecord();
            Debug.Log("✅ MicrophoneRecord started");
            
            // Record the start time for minimum duration check
            recordingStartTime = Time.realtimeSinceStartup;
            
            isListening = true;
            
            SetStatus("Listening...");
            OnRecordingStateChanged?.Invoke(true);
            
            Debug.Log("✅ AR Voice recognition started successfully");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Error in StartListening: {e.Message}");
            Debug.LogError($"❌ Stack trace: {e.StackTrace}");
            
            // Clean up on error
            isListening = false;
            SetStatus("Error starting");
            OnRecordingStateChanged?.Invoke(false);
            
            OnErrorOccurred?.Invoke($"Failed to start AR voice recognition: {e.Message}. Check microphone permissions and Whisper model setup.");
        }
    }
    
    private void StopListening()
    {
        if (!isListening) return;
        
        try
        {
            Debug.Log("🛑 Stopping voice recognition...");
            
            // Check if microphoneRecord is valid before stopping
            if (microphoneRecord == null)
            {
                Debug.LogError("❌ MicrophoneRecord is null when trying to stop!");
                OnErrorOccurred?.Invoke("MicrophoneRecord component is null - cannot stop recording");
                return;
            }
            
            // Check if microphoneRecord is currently recording
            if (!microphoneRecord.IsRecording)
            {
                Debug.LogWarning("⚠️ MicrophoneRecord was not recording when stop was called");
                // Still update state even if not recording
                isListening = false;
                SetStatus("Ready");
                OnRecordingStateChanged?.Invoke(false);
                return;
            }
            
            // Check minimum recording duration to prevent Unity microphone errors
            float recordingDuration = Time.realtimeSinceStartup - recordingStartTime;
            
            if (recordingDuration < MINIMUM_RECORDING_DURATION)
            {
                float waitTime = MINIMUM_RECORDING_DURATION - recordingDuration;
                Debug.Log($"⏱️ Recording too short ({recordingDuration:F2}s), waiting {waitTime:F2}s more...");
                
                // Use coroutine to wait for minimum duration
                StartCoroutine(StopAfterMinimumDuration(waitTime));
                return;
            }
            
            // Stop the microphone recording - WhisperStream stops automatically
            microphoneRecord.StopRecord();
            Debug.Log($"✅ MicrophoneRecord stopped successfully after {recordingDuration:F2}s");
            
            // Note: WhisperStream stops automatically when microphone stops
            // No need to manually stop the stream
            if (whisperStream != null)
            {
                Debug.Log("✅ WhisperStream will stop automatically with microphone");
            }
            
            isListening = false;
            
            SetStatus("Processing...");
            OnRecordingStateChanged?.Invoke(false); 
            
            Debug.Log("✅ AR Voice recognition stopped successfully");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Error in StopListening: {e.Message}");
            Debug.LogError($"❌ Stack trace: {e.StackTrace}");
            
            // Force update state even if stopping failed
            isListening = false;
            SetStatus("Error stopping");
            OnRecordingStateChanged?.Invoke(false);
            
            OnErrorOccurred?.Invoke($"Failed to stop recording: {e.Message}. This may be due to recording duration being too short. Try recording for at least 1 second.");
        }
    }
    
    /// <summary>
    /// Coroutine to ensure minimum recording duration before stopping
    /// </summary>
    private System.Collections.IEnumerator StopAfterMinimumDuration(float waitTime)
    {
        yield return new WaitForSecondsRealtime(waitTime);
        
        // Now try stopping again
        if (isListening && microphoneRecord != null && microphoneRecord.IsRecording)
        {
            try
            {
                float totalDuration = Time.realtimeSinceStartup - recordingStartTime;
                microphoneRecord.StopRecord();
                Debug.Log($"✅ MicrophoneRecord stopped after minimum duration ({totalDuration:F2}s)");
                
                isListening = false;
                SetStatus("Processing...");
                OnRecordingStateChanged?.Invoke(false);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ Error stopping after minimum duration: {e.Message}");
                isListening = false;
                SetStatus("Error stopping");
                OnRecordingStateChanged?.Invoke(false);
                OnErrorOccurred?.Invoke($"Failed to stop recording even after minimum duration: {e.Message}");
            }
        }
    }
    
    // Event handlers for WhisperStream
    
    private void OnTranscriptionUpdated(string transcription)
    {
        // Skip empty or very short transcriptions if real-time filtering is enabled
        if (!enableRealTimeDisplay || string.IsNullOrWhiteSpace(transcription) || transcription.Length < 2)
        {
            return;
        }
        
        // Update internal state
        lastTranscription = transcription;
        
        // Fire event for external UI (real-time partial results)
        OnTranscriptionReceived?.Invoke($"[Partial] {transcription}");
        
        // Optional direct UI update with real-time indicator
        if (statusText != null)
        {
            string displayText = transcription.Length > 15 ?
                transcription.Substring(0, 15) + "..." :
                transcription;
            statusText.text = $"🎤 {displayText}";
        }

        Debug.Log($"🎯 Real-time Transcription: {transcription}");

        // You can add custom logic here for medical dictation
        ProcessMedicalTranscription(transcription);
    }
    
    private void OnTranscriptionFinished(string finalTranscription)
    {
        // Update internal state
        lastTranscription = finalTranscription;
        
        // Fire event for external UI (final result)
        OnTranscriptionReceived?.Invoke($"[Final] {finalTranscription}");
        
        Debug.Log($"✅ Final AR Transcription: {finalTranscription}");
        
        // Auto-hide after processing if enabled
        if (autoHide)
        {
            // Use coroutine instead of Invoke for better Editor compatibility
            StartCoroutine(ResetToReadyAfterDelay(3f));
        }
        else
        {
            SetStatus("Complete");
        }
        
        // Process final transcription for medical use
        ProcessFinalMedicalTranscription(finalTranscription);
    }
    
    private void ProcessMedicalTranscription(string transcription)
    {
        // Add your medical-specific processing here
        // For example: medical terminology recognition, command processing, etc.
        
        // Example: Check for medical commands
        if (transcription.ToLower().Contains("patient"))
        {
            // Handle patient-related dictation
        }
        else if (transcription.ToLower().Contains("diagnosis"))
        {
            // Handle diagnosis dictation
        }
    }
    
    private void ProcessFinalMedicalTranscription(string finalTranscription)
    {
        // Process the complete transcription for medical documentation
        // This could save to a file, send to a medical system, etc.
        
        Debug.Log($"📋 Medical transcription ready: {finalTranscription}");
    }
    
    private void ResetToReady()
    {
        SetStatus("Ready");
    }
    
    /// <summary>
    /// Coroutine version of ResetToReady for better Editor compatibility
    /// </summary>
    private System.Collections.IEnumerator ResetToReadyAfterDelay(float delay)
    {
        yield return new WaitForSecondsRealtime(delay);
        ResetToReady();
    }
    
    /// <summary>
    /// Get reference to the WhisperManager for manual configuration
    /// </summary>
    public WhisperManager GetWhisperManager()
    {
        return whisperManager;
    }
    
    /// <summary>
    /// Get reference to the MicrophoneRecord component
    /// </summary>
    public MicrophoneRecord GetMicrophoneRecord()
    {
        return microphoneRecord;
    }
    
    /// <summary>
    /// Check if WhisperManager is properly configured and loaded
    /// </summary>
    public bool IsWhisperManagerReady()
    {
        return whisperManager != null && whisperManager.IsLoaded && isInitialized;
    }
    
    /// <summary>
    /// Force reinitialize the voice recognition system
    /// </summary>
    public void ReinitializeVoiceRecognition()
    {
        if (whisperManager != null)
        {
            StartCoroutine(InitializeVoiceRecognition());
        }
    }
    
    private System.Collections.IEnumerator ReinitializeSystem()
    {
        isInitialized = false;
        SetStatus("Reinitializing...");
        
        // Cleanup existing stream
        if (whisperStream != null)
        {
            whisperStream.OnResultUpdated -= OnTranscriptionUpdated;
            whisperStream.OnStreamFinished -= OnTranscriptionFinished;
            whisperStream = null;
        }
        
        // Reinitialize
        yield return StartCoroutine(InitializeVoiceRecognition());
    }
    
    private void OnDestroy()
    {
        // Cleanup voice recognition resources
        if (whisperStream != null)
        {
            whisperStream.OnResultUpdated -= OnTranscriptionUpdated;
            whisperStream.OnStreamFinished -= OnTranscriptionFinished;
        }
        
        if (microphoneRecord != null && microphoneRecord.IsRecording)
        {
            try
            {
                // Check if we've recorded for minimum duration
                float recordingDuration = Time.realtimeSinceStartup - recordingStartTime;
                if (recordingDuration >= MINIMUM_RECORDING_DURATION)
                {
                    microphoneRecord.StopRecord();
                    Debug.Log("✅ MicrophoneRecord stopped safely in OnDestroy");
                }
                else
                {
                    Debug.LogWarning($"⚠️ Skipping microphone stop in OnDestroy - recording too short ({recordingDuration:F2}s)");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"⚠️ Error stopping microphone in OnDestroy: {e.Message}");
            }
        }
    }
    
    // Public properties for easy integration with manual UI
    public bool IsRecording => isListening;
    public bool IsInitialized => isInitialized;
    public string LastTranscription => lastTranscription;
    public string CurrentStatus => currentStatus;
    
    // Public methods for manual UI control
    public void StartRecording()
    {
        if (isInitialized && !isListening)
        {
            StartListening();
        }
    }
    
    public void StopRecording()
    {
        if (isListening)
        {
            StopListening();
        }
    }
    
    // Real-time configuration methods
    public void SetRealTimeSettings(bool enableRealTime, float confidenceThreshold = 0.3f, float updateFrequency = 0.5f)
    {
        this.enableRealTimeDisplay = enableRealTime;
        this.confidenceThreshold = confidenceThreshold;
        this.updateFrequency = updateFrequency;
        
        Debug.Log($"Real-time settings updated: Enable={enableRealTime}, Confidence={confidenceThreshold}, Frequency={updateFrequency}");
    }
    
    public void EnableRealTimeDisplay(bool enable)
    {
        enableRealTimeDisplay = enable;
        Debug.Log($"Real-time display: {(enable ? "Enabled" : "Disabled")}");
    }
}

# Voice Recognition Error Troubleshooting Guide

## ERROR DETECTED
```
Voice Recognition Error: 
ARVoiceRecognitionCore:StopListening () - Failed to stop recording
```

This error occurs when the system tries to stop voice recognition but encounters an issue with the microphone or Whisper components.

## Common Causes and Solutions

### 1. **Microphone Permission Issues**
**Most Likely Cause**

#### Symptoms:
- Error when stopping recording
- Microphone never actually starts
- "Failed to stop recording" messages

#### Solution:
```
Unity Editor:
1. Go to Edit → Project Settings → XR Plug-in Management → Oculus
2. Ensure "Microphone" permission is enabled

Meta Quest Device:
1. Settings → Apps → MediScribe → Permissions
2. Enable Microphone permission
3. Restart the app
```

### 2. **Missing Whisper Model Files**
**Critical Requirement**

#### Check if you have:
```
Assets/StreamingAssets/Whisper/ggml-tiny.bin (or ggml-base.bin)
```

#### If missing:
1. Use `WhisperModelDownloader` component
2. Click "Download Base Model (Recommended)"
3. Wait for download to complete

### 3. **Component Assignment Issues**

#### Check in ARVoiceRecognitionCore Inspector:
```
✅ Whisper Manager: [Assigned to WhisperManager component]
✅ Microphone Record: [Assigned to MicrophoneRecord component]
```

#### If not assigned:
1. Use `SceneSetupChecker` component
2. Click "Check Scene Setup"
3. Click "Fix Common Issues"

### 4. **Initialization Problems**

#### Check Console for:
```
✅ AR Voice Recognition fully initialized!
```

#### If you see initialization errors:
```
❌ WhisperManager failed to load
❌ Model file doesn't exist
❌ Stream creation failed
```

**Solution:**
1. Ensure model files are downloaded
2. Check WhisperManager model path: `Whisper/ggml-base.bin`
3. Restart Unity and try again

## Enhanced Error Reporting

The system now provides detailed error information:

### New Debug Messages:
```
🎤 Starting voice recognition...
✅ WhisperStream started
✅ MicrophoneRecord started
✅ AR Voice recognition started successfully

🛑 Stopping voice recognition...
✅ MicrophoneRecord stopped successfully
✅ AR Voice recognition stopped successfully
```

### Error Details:
```
❌ Error in StopListening: [Specific error message]
❌ Stack trace: [Detailed error location]
```

## Step-by-Step Debugging

### Step 1: Check Component Setup
```
1. Add SceneSetupChecker component to any GameObject
2. Click "Check Scene Setup" 
3. Look for ✅ or ❌ messages in Console
4. Use "Fix Common Issues" if problems found
```

### Step 2: Verify Model Files
```
1. Add WhisperModelDownloader component
2. Click "Check Available Models"
3. Ensure ggml-base.bin (142 MB) is present
4. Download if missing
```

### Step 3: Test Microphone Permissions
```
Unity Editor:
- Microphone should work automatically
- Check Windows microphone permissions

Meta Quest:
- Enable microphone permission in Quest settings
- Restart app after enabling permissions
```

### Step 4: Check WhisperManager Configuration
```
In WhisperManager Inspector:
✅ Model Path: Whisper/ggml-base.bin
✅ Language: en
✅ Translate To English: ✓
✅ Print Realtime: ✓ (for debugging)
```

## Common Error Patterns

### Pattern 1: Null Reference on Stop
```
Error: "MicrophoneRecord is null when trying to stop"
Solution: Check component assignments in Inspector
```

### Pattern 2: Microphone Not Recording  
```
Error: "MicrophoneRecord was not recording when stop was called"
Solution: Check microphone permissions and initialization
```

### Pattern 3: Stream Issues
```
Error: "WhisperStream handling stopped"
Status: RESOLVED - WhisperStream stops automatically when microphone stops
Note: No manual stream stopping required
```

### Pattern 4: Permission Denied
```
Error: "Failed to start AR voice recognition: Permission denied"
Solution: Enable microphone permissions for Unity/Quest app
```

### Pattern 5: Audio Clip Duration Error (FIXED)
```
Error: "Length of created clip must be larger than 0"
Status: ✅ RESOLVED - Added minimum recording duration logic
Solution: System now automatically waits for minimum duration before stopping
Note: Hold record button for at least 0.5 seconds for best results
```

### Pattern 6: Unity Editor UI Overflow (NOT VOICE RECOGNITION RELATED)
```
Error: "OverflowException at Selectable.get_allSelectablesArray()"
Status: Unity Editor Bug - Does NOT affect voice recognition
Solution: Restart Unity Editor, clear UI selection, or work in Game view
Note: Voice recognition works normally despite this Unity bug
```

## Testing Script for Diagnosis

Add this script to test microphone functionality:

```csharp
using UnityEngine;
using Whisper.Utils;

public class MicrophoneTest : MonoBehaviour
{
    [ContextMenu("Test Microphone")]
    void TestMicrophone()
    {
        Debug.Log("🔍 TESTING MICROPHONE...");
        
        // Check available devices
        string[] devices = Microphone.devices;
        Debug.Log($"Available microphones: {devices.Length}");
        foreach (string device in devices)
        {
            Debug.Log($"  - {device}");
        }
        
        // Test basic recording
        if (devices.Length > 0)
        {
            Debug.Log("✅ Microphone devices found");
            
            // Check permissions
            if (Application.HasUserAuthorization(UserAuthorization.Microphone))
            {
                Debug.Log("✅ Microphone permission granted");
            }
            else
            {
                Debug.LogError("❌ Microphone permission denied!");
            }
        }
        else
        {
            Debug.LogError("❌ No microphone devices found!");
        }
    }
}
```

## Quick Fixes Checklist

✅ **Download model files** (use WhisperModelDownloader)
✅ **Check component assignments** (use SceneSetupChecker)  
✅ **Enable microphone permissions** (Unity/Quest settings)
✅ **Configure WhisperManager** (model path: Whisper/ggml-base.bin)
✅ **Test in Unity Editor first** (before deploying to Quest)
✅ **Check Console for detailed error messages** (new enhanced logging)

## For Meta Quest Specific Issues

### Quest Permission Setup:
1. **Settings → Apps → [Your App] → Permissions**
2. **Enable Microphone**
3. **Restart the application**

### Quest Performance:
1. **Use ggml-base.bin** (not larger models)
2. **Test with simple phrases first**
3. **Check Quest storage space** (models need disk space)

The enhanced error reporting should now show you exactly what's failing in the stop/start process!

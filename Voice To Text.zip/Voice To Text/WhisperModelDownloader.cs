using UnityEngine;
using System.IO;
using System.Collections;
using UnityEngine.Networking;

/// <summary>
/// Automatic Whisper model downloader for AR Voice Recognition.
/// This script will automatically download required Whisper model files.
/// </summary>
public class WhisperModelDownloader : MonoBehaviour
{
    [Header("Model Download Settings")]
    [Tooltip("Which model to download automatically")]
    public ModelSize targetModel = ModelSize.Base;
    
    [Tooltip("Automatically download on Start")]
    public bool autoDownloadOnStart = true;
    
    [Header("Download Status")]
    [SerializeField] private bool isDownloading = false;
    [SerializeField] private float downloadProgress = 0f;
    [SerializeField] private string downloadStatus = "Ready";
    [SerializeField] private long downloadedBytes = 0;
    [SerializeField] private long totalBytes = 0;
    
    public enum ModelSize
    {
        Tiny,   // 39 MB - Fastest, least accurate
        Base,   // 142 MB - Recommended for Medical AR
        Small   // 244 MB - Highest accuracy
    }
    
    private struct ModelInfo
    {
        public string fileName;
        public string downloadUrl;
        public long expectedSize;
    }
    
    void Start()
    {
        if (autoDownloadOnStart)
        {
            CheckAndDownloadModel();
        }
    }
    
    [ContextMenu("Check and Download Model")]
    public void CheckAndDownloadModel()
    {
        StartCoroutine(CheckAndDownloadCoroutine());
    }
    
    [ContextMenu("Download Tiny Model")]
    public void DownloadTinyModel()
    {
        targetModel = ModelSize.Tiny;
        StartCoroutine(DownloadModelCoroutine(targetModel));
    }
    
    [ContextMenu("Download Base Model (Recommended)")]
    public void DownloadBaseModel()
    {
        targetModel = ModelSize.Base;
        StartCoroutine(DownloadModelCoroutine(targetModel));
    }
    
    [ContextMenu("Download Small Model")]
    public void DownloadSmallModel()
    {
        targetModel = ModelSize.Small;
        StartCoroutine(DownloadModelCoroutine(targetModel));
    }
    
    private IEnumerator CheckAndDownloadCoroutine()
    {
        ModelInfo modelInfo = GetModelInfo(targetModel);
        string streamingPath = Application.streamingAssetsPath;
        string whisperDir = Path.Combine(streamingPath, "Whisper");
        string modelPath = Path.Combine(whisperDir, modelInfo.fileName);
        
        downloadStatus = "Checking existing files...";
        
        // Check if model already exists
        if (File.Exists(modelPath))
        {
            FileInfo fileInfo = new FileInfo(modelPath);
            if (fileInfo.Length == modelInfo.expectedSize)
            {
                downloadStatus = $"✅ {modelInfo.fileName} already exists and is valid";
                Debug.Log($"✅ Model file {modelInfo.fileName} already exists ({fileInfo.Length / (1024*1024)} MB)");
                yield break;
            }
            else
            {
                Debug.LogWarning($"⚠️ Model file exists but wrong size. Re-downloading...");
                File.Delete(modelPath);
            }
        }
        
        // Download the model
        yield return StartCoroutine(DownloadModelCoroutine(targetModel));
    }
    
    private IEnumerator DownloadModelCoroutine(ModelSize model)
    {
        if (isDownloading)
        {
            Debug.LogWarning("Download already in progress!");
            yield break;
        }
        
        ModelInfo modelInfo = GetModelInfo(model);
        string streamingPath = Application.streamingAssetsPath;
        string whisperDir = Path.Combine(streamingPath, "Whisper");
        string modelPath = Path.Combine(whisperDir, modelInfo.fileName);
        
        // Create directories if they don't exist
        if (!Directory.Exists(whisperDir))
        {
            Directory.CreateDirectory(whisperDir);
            Debug.Log($"Created directory: {whisperDir}");
        }
        
        isDownloading = true;
        downloadProgress = 0f;
        downloadedBytes = 0;
        totalBytes = modelInfo.expectedSize;
        downloadStatus = $"Downloading {modelInfo.fileName}...";
        
        Debug.Log($"🔽 Starting download of {modelInfo.fileName} ({modelInfo.expectedSize / (1024*1024)} MB)");
        Debug.Log($"📥 URL: {modelInfo.downloadUrl}");
        
        using (UnityWebRequest www = UnityWebRequest.Get(modelInfo.downloadUrl))
        {
            var operation = www.SendWebRequest();
            
            while (!operation.isDone)
            {
                downloadProgress = www.downloadProgress;
                downloadedBytes = (long)(www.downloadProgress * modelInfo.expectedSize);
                downloadStatus = $"Downloading {modelInfo.fileName}: {downloadProgress * 100:F1}%";
                
                yield return null;
            }
            
            if (www.result == UnityWebRequest.Result.Success)
            {
                downloadStatus = "Writing file...";
                
                try
                {
                    File.WriteAllBytes(modelPath, www.downloadHandler.data);
                    
                    // Verify file size
                    FileInfo fileInfo = new FileInfo(modelPath);
                    if (fileInfo.Length == modelInfo.expectedSize)
                    {
                        downloadStatus = $"✅ {modelInfo.fileName} downloaded successfully!";
                        Debug.Log($"✅ Successfully downloaded {modelInfo.fileName} ({fileInfo.Length / (1024*1024)} MB)");
                        Debug.Log($"📁 Saved to: {modelPath}");
                        
                        // Try to update WhisperManager if it exists
                        UpdateWhisperManagerPath(modelInfo.fileName);
                    }
                    else
                    {
                        downloadStatus = $"❌ File size mismatch!";
                        Debug.LogError($"❌ Downloaded file size doesn't match expected size!");
                        File.Delete(modelPath);
                    }
                }
                catch (System.Exception e)
                {
                    downloadStatus = $"❌ Failed to save file: {e.Message}";
                    Debug.LogError($"❌ Failed to save model file: {e.Message}");
                }
            }
            else
            {
                downloadStatus = $"❌ Download failed: {www.error}";
                Debug.LogError($"❌ Download failed: {www.error}");
                Debug.LogError($"Response Code: {www.responseCode}");
            }
        }
        
        isDownloading = false;
        downloadProgress = 1f;
    }
    
    private ModelInfo GetModelInfo(ModelSize model)
    {
        switch (model)
        {
            case ModelSize.Tiny:
                return new ModelInfo
                {
                    fileName = "ggml-tiny.bin",
                    downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin",
                    expectedSize = 39062856 // ~39 MB
                };
                
            case ModelSize.Base:
                return new ModelInfo
                {
                    fileName = "ggml-base.bin",
                    downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin",
                    expectedSize = 148115888 // ~142 MB
                };
                
            case ModelSize.Small:
                return new ModelInfo
                {
                    fileName = "ggml-small.bin",
                    downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin",
                    expectedSize = 256026560 // ~244 MB
                };
                
            default:
                return GetModelInfo(ModelSize.Base);
        }
    }
    
    private void UpdateWhisperManagerPath(string fileName)
    {
        var whisperManager = FindFirstObjectByType<Whisper.WhisperManager>();
        if (whisperManager != null)
        {
            // Use reflection or direct assignment if possible
            Debug.Log($"🔧 Found WhisperManager - please set Model Path to: Whisper/{fileName}");
            Debug.Log($"📋 In WhisperManager Inspector, set:");
            Debug.Log($"   Model Path: Whisper/{fileName}");
            Debug.Log($"   Language: en (for medical AR)");
        }
        else
        {
            Debug.Log($"ℹ️ No WhisperManager found. When you create one, set Model Path to: Whisper/{fileName}");
        }
    }
    
    [ContextMenu("Check Available Models")]
    public void CheckAvailableModels()
    {
        string streamingPath = Application.streamingAssetsPath;
        string whisperDir = Path.Combine(streamingPath, "Whisper");
        
        Debug.Log("🔍 CHECKING AVAILABLE WHISPER MODELS:");
        
        if (!Directory.Exists(whisperDir))
        {
            Debug.LogError("❌ Whisper directory doesn't exist!");
            Debug.LogError($"Expected: {whisperDir}");
            return;
        }
        
        ModelSize[] models = { ModelSize.Tiny, ModelSize.Base, ModelSize.Small };
        
        foreach (ModelSize model in models)
        {
            ModelInfo info = GetModelInfo(model);
            string modelPath = Path.Combine(whisperDir, info.fileName);
            
            if (File.Exists(modelPath))
            {
                FileInfo fileInfo = new FileInfo(modelPath);
                bool sizeCorrect = fileInfo.Length == info.expectedSize;
                string status = sizeCorrect ? "✅ Valid" : "⚠️ Wrong size";
                
                Debug.Log($"{status} {info.fileName} ({fileInfo.Length / (1024*1024)} MB)");
            }
            else
            {
                Debug.Log($"❌ Missing {info.fileName}");
            }
        }
    }
}

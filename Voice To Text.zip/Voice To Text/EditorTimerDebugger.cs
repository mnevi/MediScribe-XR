using UnityEngine;
using System.Collections;

/// <summary>
/// Debug script to investigate timer and coroutine behavior differences 
/// between Unity Editor and device builds.
/// 
/// Attach this to a GameObject to test various timing mechanisms and see 
/// which ones work reliably in both Editor and device builds.
/// </summary>
public class EditorTimerDebugger : MonoBehaviour
{
    [Header("Debug Settings")]
    public bool enableDebugLogs = true;
    public float testDuration = 5f;
    
    [Header("Test Results (Read Only)")]
    public bool isInEditor;
    public float timeScaleValue;
    public float realTimeSinceStartup;
    public float unscaledTime;
    
    private float startTime;
    private Coroutine testCoroutine;
    
    void Start()
    {
        isInEditor = Application.isEditor;
        timeScaleValue = Time.timeScale;
        
        Log($"🔍 TIMER DEBUGGER STARTED");
        Log($"   Editor: {isInEditor}");
        Log($"   Platform: {Application.platform}");
        Log($"   Time Scale: {Time.timeScale}");
        Log($"   Frame Rate: {Application.targetFrameRate}");
        
        StartTimerTests();
    }
    
    void Update()
    {
        // Update runtime values
        realTimeSinceStartup = Time.realtimeSinceStartup;
        unscaledTime = Time.unscaledTime;
        timeScaleValue = Time.timeScale;
    }
    
    public void StartTimerTests()
    {
        Log("🔍 Starting comprehensive timer tests...");
        
        // Test 1: Basic WaitForSeconds
        StartCoroutine(TestBasicWaitForSeconds());
        
        // Test 2: WaitForSecondsRealtime
        StartCoroutine(TestWaitForSecondsRealtime());
        
        // Test 3: Custom frame-based timer
        StartCoroutine(TestFrameBasedTimer());
        
        // Test 4: Invoke method
        TestInvokeMethod();
        
        // Test 5: Combined approach (what we use in AR Voice Recognition)
        StartCoroutine(TestCombinedApproach());
    }
    
    private IEnumerator TestBasicWaitForSeconds()
    {
        Log("🔍 Test 1: Basic WaitForSeconds");
        float startTime = Time.time;
        
        yield return new WaitForSeconds(2f);
        
        float elapsed = Time.time - startTime;
        Log($"   WaitForSeconds(2f) actual time: {elapsed:F2}s");
        
        if (Mathf.Abs(elapsed - 2f) > 0.2f)
        {
            LogWarning($"   WaitForSeconds timing is off by {Mathf.Abs(elapsed - 2f):F2}s!");
        }
    }
    
    private IEnumerator TestWaitForSecondsRealtime()
    {
        Log("🔍 Test 2: WaitForSecondsRealtime");
        float startTime = Time.realtimeSinceStartup;
        
        yield return new WaitForSecondsRealtime(2f);
        
        float elapsed = Time.realtimeSinceStartup - startTime;
        Log($"   WaitForSecondsRealtime(2f) actual time: {elapsed:F2}s");
        
        if (Mathf.Abs(elapsed - 2f) > 0.2f)
        {
            LogWarning($"   WaitForSecondsRealtime timing is off by {Mathf.Abs(elapsed - 2f):F2}s!");
        }
    }
    
    private IEnumerator TestFrameBasedTimer()
    {
        Log("🔍 Test 3: Frame-based timer");
        float startTime = Time.realtimeSinceStartup;
        float timer = 0f;
        float targetTime = 2f;
        
        while (timer < targetTime)
        {
            yield return null; // Wait one frame
            timer += Time.unscaledDeltaTime;
        }
        
        float elapsed = Time.realtimeSinceStartup - startTime;
        Log($"   Frame-based timer(2f) actual time: {elapsed:F2}s");
        
        if (Mathf.Abs(elapsed - 2f) > 0.2f)
        {
            LogWarning($"   Frame-based timer timing is off by {Mathf.Abs(elapsed - 2f):F2}s!");
        }
    }
    
    private void TestInvokeMethod()
    {
        Log("🔍 Test 4: Invoke method");
        startTime = Time.realtimeSinceStartup;
        Invoke(nameof(InvokeCallback), 2f);
    }
    
    private void InvokeCallback()
    {
        float elapsed = Time.realtimeSinceStartup - startTime;
        Log($"   Invoke(2f) actual time: {elapsed:F2}s");
        
        if (Mathf.Abs(elapsed - 2f) > 0.2f)
        {
            LogWarning($"   Invoke timing is off by {Mathf.Abs(elapsed - 2f):F2}s!");
        }
    }
    
    private IEnumerator TestCombinedApproach()
    {
        Log("🔍 Test 5: Combined approach (AR Voice Recognition style)");
        float startTime = Time.realtimeSinceStartup;
        float timer = 0f;
        float targetTime = 2f;
        
        while (timer < targetTime)
        {
            // Multiple yield strategies
            yield return new WaitForSeconds(0.1f);
            yield return null; // Wait one frame
            timer += 0.1f;
        }
        
        float elapsed = Time.realtimeSinceStartup - startTime;
        Log($"   Combined approach(2f) actual time: {elapsed:F2}s");
        
        if (Mathf.Abs(elapsed - 2f) > 0.2f)
        {
            LogWarning($"   Combined approach timing is off by {Mathf.Abs(elapsed - 2f):F2}s!");
        }
        
        Log("🔍 All timer tests completed!");
    }
    
    /// <summary>
    /// Test the specific pattern used in AR Voice Recognition initialization
    /// </summary>
    public void TestARVoiceRecognitionPattern()
    {
        Log("🔍 Testing AR Voice Recognition initialization pattern...");
        StartCoroutine(SimulateARInitialization());
    }
    
    private IEnumerator SimulateARInitialization()
    {
        bool mockIsLoaded = false;
        float timeout = 5f;
        float timer = 0f;
        
        Log("🔍 Starting mock initialization loop...");
        
        // Simulate the condition becoming true after 3 seconds
        StartCoroutine(SimulateMockLoading());
        
        while (!mockIsLoaded && timer < timeout)
        {
            Log($"🔍 Mock loading... {timer:F1}s (IsLoaded: {mockIsLoaded})");
            
            // Use the same pattern as AR Voice Recognition
            yield return new WaitForSeconds(0.1f);
            yield return null; // Wait one frame
            
            timer += 0.1f;
            
            // Check if our mock loading completed
            if (timer >= 3f)
                mockIsLoaded = true;
        }
        
        if (mockIsLoaded)
        {
            Log($"🔍 Mock initialization successful! Took {timer:F1}s");
        }
        else
        {
            LogWarning($"🔍 Mock initialization timed out after {timer:F1}s");
        }
    }
    
    private IEnumerator SimulateMockLoading()
    {
        yield return new WaitForSeconds(3f);
        Log("🔍 Mock loading completed!");
    }
    
    private void Log(string message)
    {
        if (enableDebugLogs)
        {
            Debug.Log($"[EditorTimerDebugger] {message}");
        }
    }
    
    private void LogWarning(string message)
    {
        if (enableDebugLogs)
        {
            Debug.LogWarning($"[EditorTimerDebugger] {message}");
        }
    }
    
    void OnDestroy()
    {
        // Clean up any running tests
        if (testCoroutine != null)
        {
            StopCoroutine(testCoroutine);
        }
        
        CancelInvoke();
    }
}

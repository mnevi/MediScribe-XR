/**
public class MedicalNoteTaker : MonoBehaviour
{
    private ARVoiceRecognitionCore voiceCore;

    void Start()
    {
        voiceCore = FindObjectOfType<ARVoiceRecognitionCore>();
        voiceCore.OnTranscriptionReceived.AddListener(SaveMedicalNote);
    }

    void SaveMedicalNote(string transcription)
    {
        // Save to patient record, database, etc.
        PatientRecord.AddNote(transcription);
    }

    public void StartDictation()
    {
        voiceCore.StartRecording();
    }
}
**/
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Simple voice recognition button that integrates with ARVoiceRecognitionCore
/// Green = Ready to record, Red = Recording (can stop), Gray = Processing/Error
/// </summary>
public class VoiceRecognitionButton : MonoBehaviour
{
    [Header("Button Components")]
    public Button button;
    public TextMeshProUGUI buttonText;
    
    [Header("Button States")]
    public string readyText = "🎤 Record";
    public string recordingText = "⏹️ Stop";
    public string processingText = "⏳ Processing...";
    
    [Header("Button Colors")]
    public Color readyColor = Color.green;      // Ready to record
    public Color recordingColor = Color.red;    // Recording (can stop)
    public Color processingColor = Color.gray;  // Processing/Error/Not ready
    
    [Header("Voice Recognition")]
    public ARVoiceRecognitionCore voiceCore;
    
    // Current state
    private bool isRecording = false;
    private bool isProcessing = false;
    
    void Start()
    {
        // Find components if not assigned
        if (button == null) button = GetComponent<Button>();
        if (buttonText == null) buttonText = GetComponentInChildren<TextMeshProUGUI>();
        if (voiceCore == null) voiceCore = FindFirstObjectByType<ARVoiceRecognitionCore>();
        
        // Setup button
        if (button != null)
        {
            button.onClick.AddListener(OnButtonClick);
        }
        
        // Connect to voice recognition events
        if (voiceCore != null)
        {
            try
            {
                voiceCore.OnRecordingStateChanged.AddListener(OnRecordingStateChanged);
                voiceCore.OnStatusChanged.AddListener(OnStatusChanged);
                voiceCore.OnErrorOccurred.AddListener(OnErrorOccurred);
                Debug.Log("✅ Voice recognition events connected successfully");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"❌ Error connecting to voice recognition events: {e.Message}");
                // Continue anyway - button will still work for visual changes
            }
        }
        
        // Set initial state
        UpdateButtonState();
    }
    
    void OnButtonClick()
    {
        if (voiceCore == null) return;
        
        try
        {
            Debug.Log($"🎤 Button clicked - attempting to toggle voice recognition");
            voiceCore.ToggleVoiceRecognition();
            Debug.Log($"✅ Voice recognition toggle completed successfully");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ CRASH PREVENTED: Voice recognition error: {e.Message}");
            Debug.LogError($"❌ Stack trace: {e.StackTrace}");
            
            // Set button to processing/error state to prevent further clicks
            isProcessing = true;
            UpdateButtonState();
            
            // Don't crash - just log the error and continue
            Debug.Log("🔄 Button remains functional despite voice recognition error");
        }
    }
    
    void OnRecordingStateChanged(bool recording)
    {
        try
        {
            isRecording = recording;
            UpdateButtonState();
            Debug.Log($"🎯 Recording state changed: {recording}");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Error handling recording state change: {e.Message}");
        }
    }
    
    void OnStatusChanged(string status)
    {
        try
        {
            // Determine if we're processing
            isProcessing = status.Contains("Processing") || 
                          status.Contains("Loading") || 
                          status.Contains("Not ready") ||
                          status.Contains("Error");
            
            UpdateButtonState();
            Debug.Log($"📊 Status changed: {status} (Processing: {isProcessing})");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Error handling status change: {e.Message}");
        }
    }
    
    void OnErrorOccurred(string error)
    {
        try
        {
            Debug.LogError($"🚨 Voice recognition error occurred: {error}");
            isProcessing = true;
            UpdateButtonState();
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Error handling voice recognition error: {e.Message}");
        }
    }
    
    void UpdateButtonState()
    {
        if (button == null) return;
        
        try
        {
            // Determine button state
            string text;
            Color color;
            bool interactable;
            
            if (isProcessing)
            {
                // Gray - Processing/Error/Not ready
                text = processingText;
                color = processingColor;
                interactable = false;
            }
            else if (isRecording)
            {
                // Red - Recording (can stop)
                text = recordingText;
                color = recordingColor;
                interactable = true;
            }
            else
            {
                // Green - Ready to record
                text = readyText;
                color = readyColor;
                interactable = true;
            }
            
            // Update button safely
            if (buttonText != null) buttonText.text = text;
            button.interactable = interactable;
            
            ColorBlock colors = button.colors;
            colors.normalColor = color;
            button.colors = colors;
            
            Debug.Log($"🎨 Button state updated - Color: {color}, Text: {text}, Interactable: {interactable}");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"❌ Error updating button state: {e.Message}");
        }
    }
    
    void OnDestroy()
    {
        // Clean up event listeners
        if (voiceCore != null)
        {
            voiceCore.OnRecordingStateChanged.RemoveListener(OnRecordingStateChanged);
            voiceCore.OnStatusChanged.RemoveListener(OnStatusChanged);
            voiceCore.OnErrorOccurred.RemoveListener(OnErrorOccurred);
        }
        
        if (button != null)
        {
            button.onClick.RemoveListener(OnButtonClick);
        }
    }
}
